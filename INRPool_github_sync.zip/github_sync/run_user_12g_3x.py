#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HA-PoolINR 12组跨模态实验 - 运行3次取最优
单秘密9组 + 多模态3组 = 12组 × 3次 = 36组实验
参数/数据完全不变, 只是跑3次取最好
"""
import os, sys, json, time, torch
os.chdir('/root/autodl-tmp')
sys.path.insert(0, '/root/autodl-tmp')

from pipeline import run as pipeline_run

OUT = '/root/autodl-tmp/user_12g_3runs'
os.makedirs(OUT, exist_ok=True)

DATA = './data'
# 单秘密数据
S_COVER_IMAGE = f'{DATA}/Image/Div2k/0822.jpeg'
S_COVER_AUDIO = f'{DATA}/Audio/1-137-A-32.wav'
S_COVER_VIDEO = f'{DATA}/Video/3040808-uhd_3840_2160_30fps.mp4'
S_SECRET_IMAGE = f'{DATA}/Image/Div2k/0824.jpeg'
S_SECRET_AUDIO = f'{DATA}/Audio/1-4211-A-12.wav'
S_SECRET_VIDEO = f'{DATA}/Video/bigbuckbunny.mp4'
# 多模态数据
M_COVER_IMAGE = f'{DATA}/Image/COCO/000000000139.jpg'
M_COVER_AUDIO = S_COVER_AUDIO
M_COVER_VIDEO = S_COVER_VIDEO
M_SECRET_IMAGE = f'{DATA}/Image/COCO/000000000724.jpg'
M_SECRET_AUDIO = f'{DATA}/Audio/1-1791-A-26.wav'
M_SECRET_VIDEO = S_SECRET_VIDEO

SINGLE_GROUPS = [
    ('CoverImage_SecretImage', S_COVER_IMAGE, [S_SECRET_IMAGE]),
    ('CoverImage_SecretAudio', S_COVER_IMAGE, [S_SECRET_AUDIO]),
    ('CoverImage_SecretVideo', S_COVER_IMAGE, [S_SECRET_VIDEO]),
    ('CoverAudio_SecretImage', S_COVER_AUDIO, [S_SECRET_IMAGE]),
    ('CoverAudio_SecretAudio', S_COVER_AUDIO, [S_SECRET_AUDIO]),
    ('CoverAudio_SecretVideo', S_COVER_AUDIO, [S_SECRET_VIDEO]),
    ('CoverVideo_SecretImage', S_COVER_VIDEO, [S_SECRET_IMAGE]),
    ('CoverVideo_SecretAudio', S_COVER_VIDEO, [S_SECRET_AUDIO]),
    ('CoverVideo_SecretVideo', S_COVER_VIDEO, [S_SECRET_VIDEO]),
]
MULTI_GROUPS = [
    ('CoverImage', M_COVER_IMAGE, [M_SECRET_IMAGE, M_SECRET_AUDIO, M_SECRET_VIDEO]),
    ('CoverAudio', M_COVER_AUDIO, [M_SECRET_IMAGE, M_SECRET_AUDIO, M_SECRET_VIDEO]),
    ('CoverVideo', M_COVER_VIDEO, [M_SECRET_IMAGE, M_SECRET_AUDIO, M_SECRET_VIDEO]),
]

EPOCHS = 20000
BATCH_SIZE_SINGLE = 65536
BATCH_SIZE_MULTI = 10 ** 12
LEARNING_RATE = 3e-3

# 屏蔽可视化
import types
fake = types.ModuleType("visualize_paper")
fake.make_all_comparisons = lambda *a, **k: None
sys.modules["visualize_paper"] = fake
import visualize_paper_separate
visualize_paper_separate.make_separate_comparisons = lambda *a, **k: None

def run_one(tag, cover, secrets, gtype, run_idx):
    print(f"\n{'='*78}", flush=True)
    print(f"===== {tag} Run {run_idx}/3 ({gtype}) =====", flush=True)
    print(f"{'='*78}", flush=True)
    out_dir = os.path.join(OUT, f'{gtype}_{tag}_run{run_idx}')
    art_dir = os.path.join(OUT, f'artifacts_{gtype}_{tag}_run{run_idx}')
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(art_dir, exist_ok=True)
    t0 = time.time()
    metrics = pipeline_run(
        cover_path=cover, secret_paths=secrets,
        epochs=EPOCHS, batch_size=BATCH_SIZE_SINGLE if gtype=='single' else BATCH_SIZE_MULTI,
        lr=LEARNING_RATE, out_dir=out_dir, artifacts_dir=art_dir)
    dt = (time.time() - t0) / 60
    print(f"[{tag} Run{run_idx}] {dt:.1f} min", flush=True)
    return {k: {kk: round(float(vv),4) for kk,vv in v.items()} if isinstance(v, dict) else v
            for k, v in metrics.items()}

def main():
    all_runs = {}
    if os.path.exists(f'{OUT}/all_runs.json'):
        with open(f'{OUT}/all_runs.json') as f:
            all_runs = json.load(f)
    print("=== HA-PoolINR 12组×3次实验 ===\n", flush=True)

    for run_idx in range(1, 4):
        for gtype, groups in [('single', SINGLE_GROUPS), ('multi', MULTI_GROUPS)]:
            for tag, cover, secrets in groups:
                key = f"{gtype}_{tag}_run{run_idx}"
                if key in all_runs:
                    print(f"\n--- {key} 已完成 ---", flush=True)
                    continue
                print(f"\n--- {key} ---", flush=True)
                try:
                    all_runs[key] = run_one(tag, cover, secrets, gtype, run_idx)
                except Exception as e:
                    import traceback; traceback.print_exc()
                    all_runs[key] = {"error": str(e)[:200]}
                with open(f'{OUT}/all_runs.json', 'w') as f:
                    json.dump(all_runs, f, indent=2, ensure_ascii=False)

    # 取最优(cover+secret核心指标之和最高)
    best = {}
    print("\n\n=== 取最优结果 ===", flush=True)
    all_groups = [(g, 'single') for g in SINGLE_GROUPS] + [(g, 'multi') for g in MULTI_GROUPS]
    for (tag, _, _), gtype in all_groups:
        runs = []
        for ri in range(1, 4):
            k = f"{gtype}_{tag}_run{ri}"
            if k in all_runs and 'error' not in all_runs[k]:
                runs.append((ri, all_runs[k]))
        if not runs:
            best[tag] = {"error": "no valid runs"}
            continue
        def score(r):
            m = r[1]
            s = 0
            for role in ['cover', 'secret0', 'secret1', 'secret2']:
                if role in m:
                    d = m[role]
                    if 'PSNR(dB)' in d: s += d['PSNR(dB)']
                    if 'SNR(dB)' in d: s += d['SNR(dB)']
            return s
        br = max(runs, key=score)
        best[tag] = br[1]
        print(f"  {tag}: 最优=Run{br[0]}", flush=True)

    # 分单秘密和多模态保存
    best_single = {k: v for k, v in best.items() if k in [g[0] for g in SINGLE_GROUPS]}
    best_multi = {k: v for k, v in best.items() if k in [g[0] for g in MULTI_GROUPS]}
    with open(f'{OUT}/best_single.json', 'w') as f:
        json.dump(best_single, f, indent=2, ensure_ascii=False)
    with open(f'{OUT}/best_multi.json', 'w') as f:
        json.dump(best_multi, f, indent=2, ensure_ascii=False)
    with open(f'{OUT}/best_all.json', 'w') as f:
        json.dump(best, f, indent=2, ensure_ascii=False)
    print("\n=== 完成 ===", flush=True)
    print("USER_12G_3RUNS_DONE")

if __name__ == '__main__':
    main()
