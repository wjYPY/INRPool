# visualize_paper_separate.py
# 纯净版：图像 / 视频帧 无任何文字；音频只保留 x/y 轴注。

import os
import numpy as np
import torch
import torchaudio
import torchvision.io as tvio
import torch.nn.functional as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams['font.family']       = 'serif'
rcParams['font.serif']        = ['Times New Roman', 'DejaVu Serif',
                                 'Nimbus Roman', 'Liberation Serif']
rcParams['mathtext.fontset']  = 'stix'
rcParams['axes.labelsize']    = 14
rcParams['xtick.labelsize']   = 12
rcParams['ytick.labelsize']   = 12
rcParams['axes.linewidth']    = 1.0
rcParams['pdf.fonttype']      = 42
rcParams['ps.fonttype']       = 42

EXT_MAP = {'image': '.jpg', 'audio': '.wav', 'video': '.mp4'}


# ---------- 读数据 ----------
def _load_image_to_resolution(path, resolution):
    img = tvio.read_image(path).float() / 255.0
    if img.shape[0] == 1: img = img.repeat(3, 1, 1)
    if img.shape[0] == 4: img = img[:3]
    img = F.interpolate(img.unsqueeze(0), size=resolution,
                        mode='bilinear', align_corners=False).squeeze(0)
    return img.permute(1, 2, 0).clamp(0, 1).numpy()


def _load_audio_to_shape(path, duration, sample_rate):
    wav, sr = torchaudio.load(path)
    if wav.shape[0] > 1: wav = wav.mean(dim=0, keepdim=True)
    if sr != sample_rate:
        wav = torchaudio.transforms.Resample(sr, sample_rate)(wav)
    length = int(sample_rate * duration)
    if wav.shape[1] < length:
        wav = F.pad(wav, (0, length - wav.shape[1]))
    wav = wav[0, :length]
    peak = wav.abs().max().clamp(min=1e-8)
    wav = wav / peak
    return wav.numpy()


def _sample_frames_by_times(frames_thw3_float, src_fps, frame_times, start_pts_of_read):
    T_raw = frames_thw3_float.shape[0]
    if T_raw == 0:
        raise RuntimeError("空视频，无法按时间戳采样。")
    out = []
    for t in frame_times:
        rel = max(t - start_pts_of_read, 0.0)
        idx = int(round(rel * src_fps))
        idx = min(max(idx, 0), T_raw - 1)
        out.append(frames_thw3_float[idx])
    return torch.stack(out, dim=0)


def _load_video_to_shape(path, num_frames, resolution,
                         frame_times=None, start_pts=0.0, end_pts=2.0):
    frames, _, info = tvio.read_video(path, start_pts=start_pts, end_pts=end_pts, pts_unit='sec')
    frames = frames.float() / 255.0
    src_fps = info.get('video_fps', frames.shape[0] / max(end_pts - start_pts, 1e-6))
    if frame_times is not None and len(frame_times) == num_frames:
        frames = _sample_frames_by_times(frames, src_fps, frame_times, start_pts)
    else:
        T = frames.shape[0]
        if T >= num_frames:
            idx = torch.linspace(0, T - 1, num_frames).long()
            frames = frames[idx]
        else:
            frames = torch.cat([frames, frames[-1:].repeat(num_frames - T, 1, 1, 1)], dim=0)
    frames = F.interpolate(frames.permute(0, 3, 1, 2), size=resolution,
                           mode='bilinear', align_corners=False)
    frames = frames.permute(0, 2, 3, 1).clamp(0, 1)
    return (frames.numpy() * 255).astype(np.uint8)


def _load_recovered_video(path, num_frames, resolution,
                          frame_times=None, save_fps=None):
    frames, _, info = tvio.read_video(path, pts_unit='sec')
    frames = frames.float() / 255.0
    T_raw = frames.shape[0]
    read_fps = info.get('video_fps', save_fps if save_fps else T_raw)
    if frame_times is not None and len(frame_times) == num_frames:
        rel_times = [t - frame_times[0] for t in frame_times]
        frames = _sample_frames_by_times(frames, read_fps, rel_times, 0.0)
    else:
        if T_raw >= num_frames:
            idx = torch.linspace(0, T_raw - 1, num_frames).long()
            frames = frames[idx]
        elif T_raw < num_frames:
            pad_n = num_frames - T_raw
            if T_raw == 0:
                raise RuntimeError(f"读入的重建视频为空: {path}")
            frames = torch.cat([frames, frames[-1:].repeat(pad_n, 1, 1, 1)], dim=0)
    frames = F.interpolate(frames.permute(0, 3, 1, 2), size=resolution,
                           mode='bilinear', align_corners=False)
    frames = frames.permute(0, 2, 3, 1).clamp(0, 1)
    return (frames.numpy() * 255).astype(np.uint8)


# ---------- 绘图（纯净版） ----------
def _save_pure_image(arr, out_file):
    """无标题、无坐标轴、无边距。arr 可为 float[0,1] 或 uint8。"""
    if arr.dtype != np.uint8:
        arr = np.clip(arr, 0, 1)
    h, w = arr.shape[:2]
    fig = plt.figure(figsize=(w / 100.0, h / 100.0), dpi=300)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)
    ax.imshow(arr)
    fig.savefig(out_file, dpi=300, bbox_inches=None, pad_inches=0)
    plt.close(fig)
    print(f"  [Vis] Saved: {out_file}")


def _save_single_waveform(wav, sample_rate, out_file):
    """波形：无标题，只保留 x/y 轴注。"""
    n = len(wav)
    t = np.linspace(0, n / sample_rate, n)
    fig, ax = plt.subplots(figsize=(8, 3.2))
    ax.plot(t, wav, linewidth=0.5, color='#1f4e79')
    ax.set_ylim(-1.1, 1.1)
    ax.set_xlabel("Time (s)")
    ax.set_ylabel("Amplitude")
    ax.grid(alpha=0.3)
    plt.tight_layout()
    plt.savefig(out_file, bbox_inches='tight', dpi=300)
    plt.close()
    print(f"  [Vis] Saved: {out_file}")


# ---------- 主入口 ----------
def make_separate_comparisons(tasks, out_dir, fig_dir, tag: str, n_video_frames: int = 4):
    os.makedirs(fig_dir, exist_ok=True)

    for t in tasks:
        role = t['role']
        mod  = t['modality']
        cfg  = t['cfg']
        meta = t.get('meta', {})
        rec_path = os.path.join(out_dir, f"recovered_{role}_{mod}{EXT_MAP[mod]}")
        if not os.path.exists(rec_path):
            print(f"  [Vis] Missing reconstruction: {rec_path}, skip.")
            continue

        label = role.capitalize()
        prefix = f"{tag}_{label}_{mod}"

        if mod == 'image':
            res = meta.get('resolution', cfg['resolution'])
            gt  = _load_image_to_resolution(t['path'],  res)
            rec = _load_image_to_resolution(rec_path,   res)
            _save_pure_image(gt,  os.path.join(fig_dir, f"{prefix}_GT.png"))
            _save_pure_image(rec, os.path.join(fig_dir, f"{prefix}_Reconstructed.png"))

        elif mod == 'audio':
            sr  = meta.get('sample_rate', cfg['sample_rate'])
            dur = cfg['duration']
            gt  = _load_audio_to_shape(t['path'], dur, sr)
            rec = _load_audio_to_shape(rec_path,  dur, sr)
            _save_single_waveform(gt,  sr, os.path.join(fig_dir, f"{prefix}_GT.png"))
            _save_single_waveform(rec, sr, os.path.join(fig_dir, f"{prefix}_Reconstructed.png"))

        elif mod == 'video':
            T   = meta.get('num_frames', cfg['num_frames'])
            res = meta.get('resolution', cfg['resolution'])
            ft  = meta.get('frame_times', None)
            s_pts    = meta.get('start_pts', 0.0)
            e_pts    = meta.get('end_pts',   2.0)
            save_fps = meta.get('save_fps',  None)

            gt  = _load_video_to_shape(t['path'], T, res,
                                       frame_times=ft, start_pts=s_pts, end_pts=e_pts)
            rec = _load_recovered_video(rec_path, T, res,
                                        frame_times=ft, save_fps=save_fps)

            n_show = min(n_video_frames, gt.shape[0])
            sel = np.linspace(0, gt.shape[0] - 1, n_show).astype(int)

            for k, s in enumerate(sel, start=1):
                _save_pure_image(gt[s],  os.path.join(fig_dir, f"{prefix}_GT_frame{k}.png"))
                _save_pure_image(rec[s], os.path.join(fig_dir, f"{prefix}_Reconstructed_frame{k}.png"))

    print(f"\n✅ [{tag}] Separate figures saved to: {fig_dir}/")