#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
增量秘密数量容量消融实验
- 封面: 0801.jpeg (Div2k)
- 秘密: 0802.jpeg, 0803.jpeg, ... 逐张增加
- 每次: epochs=10000, batch_size=16384, kaiming_normal
- 记录: 封面4指标(PSNR/SSIM/MAE/RMSE) + 秘密图平均指标
- 保存: 每次含密恢复封面图
- 停止: 任何图像 PSNR < 25 dB
"""

import os
import sys
import json
import shutil
import glob
import time

import matplotlib
matplotlib.use('Agg')

from pipeline import run

# ==================== 实验配置 ====================
COVER_PATH = "/root/autodl-tmp/data/Image/Div2k/0801.jpeg"
SECRET_DIR = "/root/autodl-tmp/data/Image/Div2k"

EPOCHS = 10000
BATCH_SIZE = 16384
INIT_SCHEME = 'kaiming_normal'
PSNR_THRESHOLD = 25.0          # 停止阈值: 任何图像 PSNR < 25 dB

# 输出目录
BASE_OUTPUT = "/root/autodl-tmp/outputs_capacity"
COVER_IMG_DIR = os.path.join(BASE_OUTPUT, "published_covers")
RESULTS_DIR = os.path.join(BASE_OUTPUT, "results")
os.makedirs(COVER_IMG_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# ==================== 获取秘密图列表 (排序, 排除封面) ====================
all_images = sorted(
    glob.glob(os.path.join(SECRET_DIR, "*.jpeg")) +
    glob.glob(os.path.join(SECRET_DIR, "*.jpg")) +
    glob.glob(os.path.join(SECRET_DIR, "*.png"))
)
cover_basename = os.path.basename(COVER_PATH)
secret_images = [img for img in all_images if os.path.basename(img) != cover_basename]

print("=" * 70)
print("增量秘密数量容量消融实验")
print("=" * 70)
print(f"封面图: {COVER_PATH}")
print(f"可用秘密图数量: {len(secret_images)}")
print(f"每次运行: epochs={EPOCHS}, batch_size={BATCH_SIZE}, init={INIT_SCHEME}")
print(f"停止条件: 所有图像 (封面+秘密) PSNR 均 < {PSNR_THRESHOLD} dB")
print(f"输出目录: {BASE_OUTPUT}")
print("=" * 70)
sys.stdout.flush()

# ==================== 实验主循环 ====================
results_table = []
total_start = time.time()

for n_secrets in range(1, len(secret_images) + 1):
    current_secrets = secret_images[:n_secrets]

    print(f"\n{'=' * 70}")
    print(f"实验 {n_secrets}: 藏入 {n_secrets} 张秘密图")
    print(f"秘密图: {[os.path.basename(s) for s in current_secrets]}")
    print(f"{'=' * 70}")
    sys.stdout.flush()

    run_out_dir = os.path.join(BASE_OUTPUT, f"run_{n_secrets}")
    run_start = time.time()

    try:
        metrics = run(
            cover_path=COVER_PATH,
            secret_paths=current_secrets,
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            out_dir=run_out_dir,
            init_scheme=INIT_SCHEME,
            early_stop_loss=None,   # 跑满所有 epoch
        )

        elapsed = time.time() - run_start

        # ---- 提取封面指标 ----
        cover_m = metrics.get('cover', {})
        cover_psnr = cover_m.get('PSNR(dB)', 0.0)
        cover_ssim = cover_m.get('SSIM', 0.0)
        cover_mae  = cover_m.get('MAE', 0.0)
        cover_rmse = cover_m.get('RMSE', 0.0)

        # ---- 提取秘密图指标并计算平均值 ----
        secret_psnrs, secret_ssims, secret_maes, secret_rmses = [], [], [], []
        for k in sorted(metrics.keys()):
            if k.startswith('secret'):
                m = metrics[k]
                secret_psnrs.append(m.get('PSNR(dB)', 0.0))
                secret_ssims.append(m.get('SSIM', 0.0))
                secret_maes.append(m.get('MAE', 0.0))
                secret_rmses.append(m.get('RMSE', 0.0))

        n = len(secret_psnrs)
        avg_psnr = sum(secret_psnrs) / n if n else 0.0
        avg_ssim = sum(secret_ssims) / n if n else 0.0
        avg_mae  = sum(secret_maes)  / n if n else 0.0
        avg_rmse = sum(secret_rmses) / n if n else 0.0
        min_psnr_secret = min(secret_psnrs) if secret_psnrs else 0.0
        max_psnr_secret = max(secret_psnrs) if secret_psnrs else 0.0

        # ---- 保存含密恢复封面图 ----
        recovered_cover = os.path.join(run_out_dir, "recovered_cover_image.jpg")
        if os.path.exists(recovered_cover):
            save_path = os.path.join(COVER_IMG_DIR, f"cover_with_{n_secrets}secrets.jpg")
            shutil.copy(recovered_cover, save_path)
            print(f"[SAVE] 含密封面图 -> {save_path}")

        # ---- 记录结果 ----
        result = {
            'n_secrets': n_secrets,
            'secret_files': [os.path.basename(s) for s in current_secrets],
            'cover_PSNR': round(float(cover_psnr), 4),
            'cover_SSIM': round(float(cover_ssim), 4),
            'cover_MAE':  round(float(cover_mae), 4),
            'cover_RMSE': round(float(cover_rmse), 4),
            'avg_secret_PSNR': round(float(avg_psnr), 4),
            'avg_secret_SSIM': round(float(avg_ssim), 4),
            'avg_secret_MAE':  round(float(avg_mae), 4),
            'avg_secret_RMSE': round(float(avg_rmse), 4),
            'min_secret_PSNR': round(float(min_psnr_secret), 4),
            'max_secret_PSNR': round(float(max_psnr_secret), 4),
            'elapsed_sec': round(elapsed, 1),
        }
        results_table.append(result)

        # ---- 每次运行后保存中间结果 (防中断丢失) ----
        with open(os.path.join(RESULTS_DIR, 'capacity_results.json'), 'w', encoding='utf-8') as f:
            json.dump(results_table, f, indent=2, ensure_ascii=False)

        print(f"\n--- 实验 {n_secrets} 结果 ---")
        print(f"  封面:    PSNR={cover_psnr:.2f}  SSIM={cover_ssim:.4f}  MAE={cover_mae:.4f}  RMSE={cover_rmse:.4f}")
        print(f"  秘密(均值): PSNR={avg_psnr:.2f}  SSIM={avg_ssim:.4f}  MAE={avg_mae:.4f}  RMSE={avg_rmse:.4f}")
        print(f"  秘密(范围): PSNR [{min_psnr_secret:.2f} ~ {max_psnr_secret:.2f}]")
        print(f"  耗时: {elapsed:.0f}s ({elapsed/60:.1f} min)")
        sys.stdout.flush()

        # ---- 检查停止条件: 所有图像 PSNR 均 < 25 dB ----
        all_psnrs = [cover_psnr] + secret_psnrs
        min_all = min(all_psnrs)
        max_all = max(all_psnrs)
        below_count = sum(1 for p in all_psnrs if p < PSNR_THRESHOLD)
        print(f"  所有图像 PSNR 范围: [{min_all:.2f} ~ {max_all:.2f}] dB")
        print(f"  低于 {PSNR_THRESHOLD} dB 的图像数: {below_count}/{len(all_psnrs)}")

        if max_all < PSNR_THRESHOLD:
            print(f"\n{'!' * 60}")
            print(f"  所有图像 PSNR 均已低于 {PSNR_THRESHOLD} dB!")
            print(f"  最大 PSNR = {max_all:.2f} dB, 最小 PSNR = {min_all:.2f} dB")
            print(f"  在藏入 {n_secrets} 张秘密图后停止实验!")
            print(f"{'!' * 60}")
            break

    except Exception as e:
        import traceback
        print(f"\n[ERROR] 实验 {n_secrets} 失败: {e}")
        traceback.print_exc()
        # 保存已有结果
        with open(os.path.join(RESULTS_DIR, 'capacity_results.json'), 'w', encoding='utf-8') as f:
            json.dump(results_table, f, indent=2, ensure_ascii=False)
        break

# ==================== 输出汇总表格 ====================
total_elapsed = time.time() - total_start

print(f"\n\n{'=' * 120}")
print("增量秘密数量容量消融实验 — 汇总表")
print(f"{'=' * 120}")
header = (f"{'N':<5} {'Cover_PSNR':<13} {'Cover_SSIM':<13} {'Cover_MAE':<13} {'Cover_RMSE':<13} "
          f"{'AvgSec_PSNR':<14} {'AvgSec_SSIM':<14} {'AvgSec_MAE':<14} {'AvgSec_RMSE':<14} {'MinSec_PSNR':<14} {'Time(min)':<10}")
print(header)
print("-" * 120)
for r in results_table:
    row = (f"{r['n_secrets']:<5} {r['cover_PSNR']:<13.2f} {r['cover_SSIM']:<13.4f} {r['cover_MAE']:<13.4f} {r['cover_RMSE']:<13.4f} "
           f"{r['avg_secret_PSNR']:<14.2f} {r['avg_secret_SSIM']:<14.4f} {r['avg_secret_MAE']:<14.4f} {r['avg_secret_RMSE']:<14.4f} {r['min_secret_PSNR']:<14.2f} {r['elapsed_sec']/60:<10.1f}")
    print(row)
print("=" * 120)
print(f"总耗时: {total_elapsed/60:.1f} 分钟")
print(f"完成实验数: {len(results_table)}")
print(f"JSON 结果: {os.path.join(RESULTS_DIR, 'capacity_results.json')}")
print(f"含密封面图: {COVER_IMG_DIR}/")
sys.stdout.flush()
