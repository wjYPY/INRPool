# run_multimodal.py
import os
import json
import time
import torch

from pipeline import run
from visualize_paper_separate import make_separate_comparisons

# ============ 数据路径（相对当前 cwd = /root/autodl-tmp/） ============
DATA_ROOT = "./data"

COVER_IMAGE  = f"{DATA_ROOT}/Image/COCO/000000000139.jpg"
SECRET_IMAGE = f"{DATA_ROOT}/Image/COCO/000000000724.jpg"

COVER_AUDIO  = f"{DATA_ROOT}/Audio/1-137-A-32.wav"
SECRET_AUDIO = f"{DATA_ROOT}/Audio/1-1791-A-26.wav"

COVER_VIDEO  = f"{DATA_ROOT}/Video/3040808-uhd_3840_2160_30fps.mp4"
SECRET_VIDEO = f"{DATA_ROOT}/Video/bigbuckbunny.mp4"

# ============ 训练超参 ============
EPOCHS        = 20000
FULL_BATCH    = 10 ** 12
LEARNING_RATE = 3e-3

# ============ 输出目录 ============
ROOT_OUT  = "./outputs_multimodal"
ROOT_FIGS = "./paper_figures"
ROOT_ART  = "./artifacts_multimodal"
os.makedirs(ROOT_OUT,  exist_ok=True)
os.makedirs(ROOT_FIGS, exist_ok=True)
os.makedirs(ROOT_ART,  exist_ok=True)

EXPERIMENTS = [
    {"tag": "CoverImage", "cover": COVER_IMAGE,
     "secrets": [SECRET_IMAGE, SECRET_AUDIO, SECRET_VIDEO]},
    {"tag": "CoverAudio", "cover": COVER_AUDIO,
     "secrets": [SECRET_IMAGE, SECRET_AUDIO, SECRET_VIDEO]},
    {"tag": "CoverVideo", "cover": COVER_VIDEO,
     "secrets": [SECRET_IMAGE, SECRET_AUDIO, SECRET_VIDEO]},
]


# 屏蔽 pipeline.run 内部的拼接图可视化
def _install_visualization_hook():
    import sys, types
    fake = types.ModuleType("visualize_paper")
    def _noop(*args, **kwargs): return
    fake.make_all_comparisons = _noop
    sys.modules["visualize_paper"] = fake
_install_visualization_hook()


def _preflight(paths):
    missing = [p for p in paths if not os.path.exists(p)]
    return missing


def _reconstruct_tasks_for_vis(cover_path, secret_paths):
    from configs import detect_modality, MODALITY_CFG
    from data_io import load_data

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    tasks = []
    mod = detect_modality(cover_path)
    _, _, meta = load_data(mod, cover_path, MODALITY_CFG[mod], device)
    tasks.append({'role': 'cover', 'modality': mod,
                  'cfg': MODALITY_CFG[mod], 'path': cover_path, 'meta': meta})
    for i, sp in enumerate(secret_paths):
        m = detect_modality(sp)
        _, _, meta_i = load_data(m, sp, MODALITY_CFG[m], device)
        tasks.append({'role': f'secret{i}', 'modality': m,
                      'cfg': MODALITY_CFG[m], 'path': sp, 'meta': meta_i})
    return tasks


def run_one_experiment(exp):
    tag, cover, secrets = exp["tag"], exp["cover"], exp["secrets"]

    print("\n" + "=" * 78)
    print(f"===== 开始实验组: {tag} =====")
    print(f"  Cover : {cover}")
    for i, s in enumerate(secrets):
        print(f"  Secret{i}: {s}")
    print("=" * 78)

    missing = _preflight([cover] + secrets)
    if missing:
        raise FileNotFoundError(f"以下数据文件不存在: {missing}")

    out_dir = os.path.join(ROOT_OUT, tag)
    fig_dir = os.path.join(ROOT_FIGS, tag)
    art_dir = os.path.join(ROOT_ART, tag)
    for d in (out_dir, fig_dir, art_dir):
        os.makedirs(d, exist_ok=True)

    t0 = time.time()
    metrics = run(cover_path=cover, secret_paths=secrets,
                  epochs=EPOCHS, batch_size=FULL_BATCH, lr=LEARNING_RATE,
                  out_dir=out_dir, artifacts_dir=art_dir)
    print(f"\n[{tag}] 训练+评测耗时 {(time.time()-t0)/60:.1f} min")

    tasks_for_vis = _reconstruct_tasks_for_vis(cover, secrets)
    make_separate_comparisons(tasks_for_vis, out_dir=out_dir,
                              fig_dir=fig_dir, tag=tag, n_video_frames=4)
    return metrics


def _fmt(v):
    return f"{v:.4f}" if isinstance(v, float) else str(v)


def summarize_all(all_results):
    json_path = os.path.join(ROOT_FIGS, "metrics_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    print(f"\n📄 指标 JSON 已保存: {json_path}")

    md_path = os.path.join(ROOT_FIGS, "metrics_summary.md")
    lines = ["# Multimodal Recovery Metrics Summary\n"]
    for tag, per_role in all_results.items():
        lines.append(f"\n## Experiment: **{tag}**\n")
        # 错误分支：per_role 可能是字符串或 {"error": "..."}
        if isinstance(per_role, dict) and "error" in per_role and \
                all(not isinstance(v, dict) for v in per_role.values()):
            lines.append(f"> ⚠ 实验失败: `{per_role.get('error','unknown')}`\n")
            continue
        if not isinstance(per_role, dict):
            lines.append(f"> ⚠ 无有效指标: `{per_role}`\n")
            continue
        for role, mdict in per_role.items():
            if not isinstance(mdict, dict):
                lines.append(f"\n### {role}\n\n`{mdict}`\n")
                continue
            lines.append(f"\n### {role}\n")
            lines.append("| Metric | Value |")
            lines.append("|---|---|")
            for k, v in mdict.items():
                lines.append(f"| {k} | {_fmt(v)} |")
    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"📄 指标 Markdown 已保存: {md_path}")


def main():
    all_results = {}
    for exp in EXPERIMENTS:
        try:
            all_results[exp["tag"]] = run_one_experiment(exp)
        except Exception as e:
            print(f"❌ [{exp['tag']}] 实验失败: {e}")
            import traceback; traceback.print_exc()
            all_results[exp["tag"]] = {"error": str(e)}
    summarize_all(all_results)
    print("\n🎉 全部三组多模态实验完成！")


if __name__ == "__main__":
    main()