#!/usr/bin/env python
# -*- coding: utf-8 -*-
"""
ablation_study.py
=================
Comprehensive ablation study (A1-A13) for the over-parameterized pool-based
implicit neural representation steganography scheme (HA-PoolINR).

This script imports the user's existing modules (configs, pool, filler,
models, kdf, data_io, metrics) WITHOUT modification. Runtime behaviour
changes are applied via
  1) local deep-copies of MODALITY_CFG,
  2) scoped monkey-patches of KeyDerivationFunction (restored after use),
  3) subclasses of TypedParamPool (UnifiedPool),
  4) explicit choices in a re-implemented training loop.

Outputs
-------
    ablation_results/<group>/<variant>/{config.json, metrics.json, log.txt}
    ablation_tables/ablation_full.csv
    ablation_tables/<group>.tex
    ablation_figures/<group>.png
    ablation_figures/summary_grid.png

Usage
-----
    python ablation_study.py                     # run everything (default)
    python ablation_study.py --epochs 2000
    python ablation_study.py --only A02_sign_mask
    python ablation_study.py --only-variant A4b_off
    python ablation_study.py --reports-only      # just regenerate tables/figs
"""

# =============================================================================
# 0. Imports
# =============================================================================
import os
import sys
import json
import csv
import math
import time
import copy
import random
import hashlib
import argparse
import traceback
from dataclasses import dataclass, field, asdict
from typing import Dict, List, Optional, Any, Tuple

import numpy as np
import torch
import torch.nn as nn
import torch.nn.functional as F
import torch.optim as optim

import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt

# ---- User's modules (unmodified) ----
import configs
from configs import (detect_modality, MODALITY_CFG, build_arch,
                     fourier_args_from_cfg, count_params)
from pool import TypedParamPool
from filler import FillerProtocol
from models import PoolNetwork
from data_io import load_data
from metrics import EVALUATORS
import kdf
from kdf import KeyDerivationFunction

# =============================================================================
# 1. Global constants
# =============================================================================
DATA_ROOT     = './data'
COVER_PATH    = f'{DATA_ROOT}/000000000139.jpg'
SECRET_PATHS  = [
    f'{DATA_ROOT}/1-1791-A-26.wav',
    f'{DATA_ROOT}/000000000632.jpg',
    f'{DATA_ROOT}/bigbuckbunny.mp4',
]

RESULTS_ROOT  = './ablation_results'
FIG_DIR       = './ablation_figures'
TABLE_DIR     = './ablation_tables'

DEFAULT_SEED  = 2024
DEFAULT_EPOCHS = 3000

# Publication-quality matplotlib settings
plt.rcParams.update({
    'font.family'      : 'serif',
    'font.serif'       : ['DejaVu Serif', 'Times New Roman'],
    'font.size'        : 11,
    'axes.titlesize'   : 12,
    'axes.labelsize'   : 11,
    'xtick.labelsize'  : 9,
    'ytick.labelsize'  : 10,
    'legend.fontsize'  : 9,
    'axes.grid'        : True,
    'grid.alpha'       : 0.25,
    'grid.linestyle'   : '--',
    'figure.dpi'       : 120,
    'savefig.dpi'      : 300,
    'savefig.bbox'     : 'tight',
})

# =============================================================================
# 2. RunConfig
# =============================================================================
@dataclass
class RunConfig:
    """一次消融实验的全部超参数。dict 覆盖只影响本次运行。"""
    # -- naming / grouping --
    ablation_group : str = 'A00_baseline'
    variant        : str = 'baseline'

    # -- data --
    cover_path     : str = COVER_PATH
    secret_paths   : List[str] = field(default_factory=lambda: list(SECRET_PATHS))

    # -- pool --
    pool_w         : int = 300_000
    pool_b         : int = 1_000
    pool_mode      : str = 'shared_wb'          # shared_wb | isolated | unified

    # -- training --
    epochs         : int = DEFAULT_EPOCHS
    batch_size     : int = 16384
    lr             : float = 3e-3
    optimizer      : str = 'adamw'              # adam | adamw | radam | sgd (adamw=生产pipeline一致)
    scheduler      : str = 'cosine'             # cosine | constant | step
    grad_clip      : float = 1.0                # <=0 disables
    early_stop_loss: Optional[float] = 1e-7
    seed           : int = DEFAULT_SEED

    # -- task weights --
    task_weights   : Dict[str, float] = field(
        default_factory=lambda: {'cover': 1.0, 'image': 1.0,
                                 'audio': 1.0, 'video': 1.0})

    # -- STFT auxiliary loss (audio only, weight 0 = off) --
    stft_loss_weight: float = 0.0

    # -- network micro-choices --
    leaky_slope    : float = 0.01

    # Per-modality overrides. Missing key => keep MODALITY_CFG default.
    force_is_siren       : Optional[Dict[str, bool]]  = None
    force_use_fourier    : Optional[Dict[str, bool]]  = None
    force_fourier_scale  : Optional[Dict[str, float]] = None
    force_fourier_mapping: Optional[Dict[str, int]]   = None

    # -- KDF patches (scoped) --
    kdf_no_sign    : bool = False
    kdf_no_perm    : bool = False

    # -- misc --
    auto_expand    : bool = False

    def key(self) -> str:
        return f"{self.ablation_group}__{self.variant}"


# =============================================================================
# 3. Helpers
# =============================================================================
def set_seed(seed: int):
    random.seed(seed); np.random.seed(seed)
    torch.manual_seed(seed); torch.cuda.manual_seed_all(seed)
    torch.backends.cudnn.deterministic = True
    torch.backends.cudnn.benchmark     = False


def apply_config_overrides(rcfg: RunConfig) -> Dict[str, Dict]:
    """
    深拷贝 MODALITY_CFG,按 RunConfig 里的 force_* 应用覆盖,不污染全局。
    """
    cfg_map = copy.deepcopy(MODALITY_CFG)
    for mod, cfg in cfg_map.items():
        if rcfg.force_is_siren and mod in rcfg.force_is_siren:
            cfg['is_siren'] = rcfg.force_is_siren[mod]
        if rcfg.force_use_fourier and mod in rcfg.force_use_fourier:
            cfg['use_fourier'] = rcfg.force_use_fourier[mod]
        if rcfg.force_fourier_scale and mod in rcfg.force_fourier_scale:
            cfg['fourier_scale'] = float(rcfg.force_fourier_scale[mod])
        if rcfg.force_fourier_mapping and mod in rcfg.force_fourier_mapping:
            cfg['fourier_mapping'] = int(rcfg.force_fourier_mapping[mod])
    return cfg_map


class KDFPatch:
    """
    上下文管理器: 临时修改 KeyDerivationFunction 的 sign_mask / pool_permutation。
    退出时严格还原,保证不同变体互不影响。
    """
    def __init__(self, no_sign: bool = False, no_perm: bool = False):
        self.no_sign = no_sign
        self.no_perm = no_perm
        self._orig_sign = None
        self._orig_perm = None

    def __enter__(self):
        if self.no_sign:
            self._orig_sign = KeyDerivationFunction.sign_mask
            def all_ones(key, tensor_name, num_params, device='cuda'):
                return torch.ones(num_params, device=device, dtype=torch.long)
            KeyDerivationFunction.sign_mask = staticmethod(all_ones)
        if self.no_perm:
            self._orig_perm = KeyDerivationFunction.pool_permutation
            def identity_perm(key, pool_size, p_type, device='cuda'):
                return torch.arange(pool_size, device=device, dtype=torch.long)
            KeyDerivationFunction.pool_permutation = staticmethod(identity_perm)
        return self

    def __exit__(self, exc_type, exc_val, exc_tb):
        if self._orig_sign is not None:
            KeyDerivationFunction.sign_mask = self._orig_sign
        if self._orig_perm is not None:
            KeyDerivationFunction.pool_permutation = self._orig_perm


# =============================================================================
# 4. Pool variants (isolated / unified)
# =============================================================================
class UnifiedPool(TypedParamPool):
    """
    A1b 单池共享: P_W 与 P_b 复用同一段存储。
    Filler 与 PoolNetwork 仍然分别调用 pool.P_W / pool.P_b,
    但两者是同一 Tensor,因此权重与偏置索引到同一片池空间。
    """
    def __init__(self, n_total: int, device='cuda', ref_fan_in: int = 512):
        super().__init__(n_w=n_total, n_b=n_total,
                         device=device, ref_fan_in=ref_fan_in)
        self.P_b = self.P_W          # 共享存储


def build_pool(rcfg: RunConfig, device: str) -> TypedParamPool:
    if rcfg.pool_mode == 'unified':
        n_total = max(rcfg.pool_w, rcfg.pool_b)
        return UnifiedPool(n_total=n_total, device=device)
    return TypedParamPool(n_w=rcfg.pool_w, n_b=rcfg.pool_b, device=device)


# =============================================================================
# 5. Optimizer / Scheduler builders
# =============================================================================
def build_optimizer(params, rcfg: RunConfig):
    if rcfg.optimizer == 'adam':
        return optim.Adam(params, lr=rcfg.lr)
    if rcfg.optimizer == 'adamw':
        return optim.AdamW(params, lr=rcfg.lr, weight_decay=1e-4)
    if rcfg.optimizer == 'radam':
        return optim.RAdam(params, lr=rcfg.lr)
    if rcfg.optimizer == 'sgd':
        return optim.SGD(params, lr=rcfg.lr, momentum=0.9)
    raise ValueError(f"Unknown optimizer: {rcfg.optimizer}")


def build_scheduler(optimizer, rcfg: RunConfig):
    if rcfg.scheduler == 'cosine':
        return optim.lr_scheduler.CosineAnnealingLR(
            optimizer, T_max=rcfg.epochs, eta_min=1e-5)
    if rcfg.scheduler == 'constant':
        return optim.lr_scheduler.LambdaLR(optimizer, lr_lambda=lambda ep: 1.0)
    if rcfg.scheduler == 'step':
        step = max(1, rcfg.epochs // 4)
        return optim.lr_scheduler.StepLR(optimizer, step_size=step, gamma=0.5)
    raise ValueError(f"Unknown scheduler: {rcfg.scheduler}")


# =============================================================================
# 6. STFT auxiliary loss (for A9)
# =============================================================================
def stft_loss_fn(pred_wav, true_wav, n_fft=512, hop=128):
    """Single-resolution log-magnitude STFT L1 loss (audio only)."""
    pred = pred_wav.squeeze(-1) if pred_wav.dim() > 1 else pred_wav
    true = true_wav.squeeze(-1) if true_wav.dim() > 1 else true_wav
    window = torch.hann_window(n_fft, device=pred.device)
    P = torch.stft(pred, n_fft=n_fft, hop_length=hop,
                   window=window, return_complex=True).abs()
    T = torch.stft(true, n_fft=n_fft, hop_length=hop,
                   window=window, return_complex=True).abs()
    return F.l1_loss(P, T) + F.l1_loss(torch.log(P + 1e-6), torch.log(T + 1e-6))


# =============================================================================
# 7. Core experiment runner
# =============================================================================
def _make_network(rcfg, key, arch, pool_w_size, pool_b_size, cfg, device):
    return PoolNetwork(
        key=key, arch=arch,
        pool_w_size=pool_w_size, pool_b_size=pool_b_size,
        use_fourier=cfg['use_fourier'],
        fourier_args=fourier_args_from_cfg(cfg),
        is_siren=cfg['is_siren'],
        device=device,
        leaky_slope=rcfg.leaky_slope,
    ).to(device)


def _get_task_weight(rcfg: RunConfig, task: dict) -> float:
    if task['role'] == 'cover':
        return rcfg.task_weights.get('cover', 1.0)
    return rcfg.task_weights.get(task['modality'], 1.0)


def run_experiment(rcfg: RunConfig, out_dir: str) -> Dict[str, Any]:
    """
    执行一次消融变体。返回 dict:
        { 'cover': {...metrics...},
          'secret0': {...},
          ...
          'secretN_wrongkey': {...},
          '_meta': {epochs_run, wall_time_sec, cover_nW, cover_nb, ...} }
    """
    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    os.makedirs(out_dir, exist_ok=True)
    log_path = os.path.join(out_dir, 'log.txt')
    log_f = open(log_path, 'w', encoding='utf-8')
    def log(msg: str):
        print(msg)
        log_f.write(msg + '\n'); log_f.flush()

    log(f"========== [{rcfg.ablation_group}] {rcfg.variant} ==========")
    log(f"Device={device} | seed={rcfg.seed} | epochs={rcfg.epochs}")

    set_seed(rcfg.seed)
    cfg_map = apply_config_overrides(rcfg)

    # ---- tasks ----
    tasks = []
    c_mod = detect_modality(rcfg.cover_path)
    tasks.append({'role': 'cover', 'key': 'COVER_KEY_V1',
                  'modality': c_mod, 'cfg': copy.deepcopy(cfg_map[c_mod]),
                  'path': rcfg.cover_path})
    for i, sp in enumerate(rcfg.secret_paths):
        mod = detect_modality(sp)
        tasks.append({'role': f'secret{i}', 'key': f'SECRET_KEY_{i}_V1',
                      'modality': mod, 'cfg': copy.deepcopy(cfg_map[mod]),
                      'path': sp})

    # ---- auto-expand (A11) ----
    if rcfg.auto_expand and rcfg.pool_mode == 'shared_wb':
        arch0 = build_arch(tasks[0]['cfg'])
        nW, nb = count_params(arch0)
        expanded = False
        while nW < rcfg.pool_w or nb < rcfg.pool_b:
            tasks[0]['cfg']['hidden'] += 32
            arch0 = build_arch(tasks[0]['cfg'])
            nW, nb = count_params(arch0)
            expanded = True
            if tasks[0]['cfg']['hidden'] > 2048:
                log("[Auto-Expand] hidden reached 2048, stopping"); break
        if expanded:
            log(f"[Auto-Expand] cover hidden -> {tasks[0]['cfg']['hidden']}")

    # ---- arch + data ----
    for t in tasks:
        t['arch'] = build_arch(t['cfg'])
        nW, nb = count_params(t['arch'])
        log(f"  {t['role']:>8}({t['modality']:<5}) nW={nW:<8,} nb={nb:<5}  "
            f"hidden={t['cfg']['hidden']}  depth={t['cfg']['depth']}")

    for t in tasks:
        t['coords'], t['target'], t['meta'] = load_data(
            t['modality'], t['path'], t['cfg'], device)

    # ---- pool(s) ----
    if rcfg.pool_mode == 'isolated':
        pools = {t['role']: build_pool(rcfg, device) for t in tasks}
    else:
        shared = build_pool(rcfg, device)
        pools = {t['role']: shared for t in tasks}
    for p in set(id(x) for x in pools.values()):
        pass  # (deduped later)

    # ---- KDF-scoped section: build nets + train + evaluate ----
    kdf_ctx = KDFPatch(no_sign=rcfg.kdf_no_sign, no_perm=rcfg.kdf_no_perm)
    t_start = time.time()
    results: Dict[str, Any] = {}

    with kdf_ctx:
        # -- build networks --
        nets = {}
        for t in tasks:
            p = pools[t['role']]
            nets[t['role']] = _make_network(
                rcfg, key=t['key'], arch=t['arch'],
                pool_w_size=p.n_w, pool_b_size=p.n_b,
                cfg=t['cfg'], device=device)

        # -- gather trainable pool parameters --
        params, seen = [], set()
        for p in pools.values():
            if id(p) in seen: continue
            seen.add(id(p))
            p.P_W.requires_grad_(True)
            params.append(p.P_W)
            if p.P_b is not p.P_W:      # unified pool: same tensor, skip
                p.P_b.requires_grad_(True)
                params.append(p.P_b)

        optimizer = build_optimizer(params, rcfg)
        scheduler = build_scheduler(optimizer, rcfg)

        # -- train --
        log(f"[Train] optimizer={rcfg.optimizer} sched={rcfg.scheduler} "
            f"lr={rcfg.lr:.1e} clip={rcfg.grad_clip} pool={rcfg.pool_mode} "
            f"stft_w={rcfg.stft_loss_weight}")
        log_int = max(1, rcfg.epochs // 20)
        epochs_run = 0
        final_total = float('nan')

        for ep in range(rcfg.epochs + 1):
            optimizer.zero_grad()
            losses = {}
            for t in tasks:
                n = t['coords'].shape[0]
                use_full = (t['modality'] == 'audio' and rcfg.stft_loss_weight > 0)
                if use_full or rcfg.batch_size >= n:
                    idx = torch.arange(n, device=device)
                else:
                    idx = torch.randperm(n, device=device)[:rcfg.batch_size]

                p = pools[t['role']]
                pred = nets[t['role']](t['coords'][idx], p.P_W, p.P_b)
                loss = F.mse_loss(pred, t['target'][idx])

                if t['modality'] == 'audio' and rcfg.stft_loss_weight > 0 and use_full:
                    loss = loss + rcfg.stft_loss_weight * stft_loss_fn(
                        pred, t['target'][idx])
                losses[t['role']] = loss

            total = sum(_get_task_weight(rcfg, t) * losses[t['role']] for t in tasks)
            if not torch.isfinite(total):
                log(f"  ⚠ Epoch {ep}: non-finite loss, skipping")
                continue

            total.backward()
            if rcfg.grad_clip is not None and rcfg.grad_clip > 0:
                torch.nn.utils.clip_grad_norm_(params, max_norm=rcfg.grad_clip)
            optimizer.step()
            scheduler.step()
            epochs_run = ep
            final_total = float(total.item())

            if ep % log_int == 0:
                parts = " | ".join(f"{r}:{v.item():.5f}" for r, v in losses.items())
                log(f"  Ep {ep:5d} [lr:{scheduler.get_last_lr()[0]:.1e}] "
                    f"Total {total.item():.5f} | {parts}")

            if (rcfg.early_stop_loss is not None
                    and ep > 500 and total.item() < rcfg.early_stop_loss):
                log(f"[EarlyStop] Ep {ep}: total={total.item():.2e}")
                break

        wall = time.time() - t_start
        log(f"[Train Done] epochs_run={epochs_run} wall={wall:.1f}s")

        # -- evaluation --
        log("[Eval]")
        if rcfg.pool_mode == 'isolated':
            # 每任务独立池: 直接用自身池评测,不做发布/解码
           for t in tasks:
                p = pools[t['role']]
                with torch.no_grad():
                    pred = nets[t['role']](t['coords'], p.P_W, p.P_b)
                m = EVALUATORS[t['modality']](t['target'], pred, t['meta'])
                results[t['role']] = m
                log(f"  [{t['role']}] " + ", ".join(f"{k}={v:.4f}" for k, v in m.items()))
        else:
            # Publish + decode + reconstruct (真实隐写流程)
            shared_pool = pools[tasks[0]['role']]
            filler = FillerProtocol(device=device)
            with torch.no_grad():
                cover_state = filler.fill_model(
                    shared_pool, tasks[0]['key'], tasks[0]['arch'])
            cover_publish = {k: v['data'].detach() for k, v in cover_state.items()}

            cover_tensors = {
                n: {'data': cover_publish[n],
                    'type': tasks[0]['arch'][n]['type'],
                    's_tau': tasks[0]['arch'][n]['s_tau']}
                for n in cover_publish
            }
            rec_P_W, rec_P_b, cnt_W, cnt_b = filler.decode_to_pool(
                tensors=cover_tensors, key=tasks[0]['key'],
                arch=tasks[0]['arch'],
                pool_w_size=shared_pool.n_w,
                pool_b_size=shared_pool.n_b)

            rec_pool = TypedParamPool(
                n_w=shared_pool.n_w, n_b=shared_pool.n_b, device=device)
            rec_pool.P_W = rec_P_W
            rec_pool.P_b = rec_P_b

            for t in tasks:
                with torch.no_grad():
                    pred = nets[t['role']](t['coords'], rec_pool.P_W, rec_pool.P_b)
                m = EVALUATORS[t['modality']](t['target'], pred, t['meta'])
                results[t['role']] = m
                log(f"  [{t['role']:>8}] " + ", ".join(
                    f"{k}={v:.4f}" for k, v in m.items()))

            # Wrong-key attack on every secret
            for t in tasks[1:]:
                wrong_net = _make_network(
                    rcfg, key='WRONG_KEY_ATTACKER',
                    arch=t['arch'], pool_w_size=shared_pool.n_w,
                    pool_b_size=shared_pool.n_b,
                    cfg=t['cfg'], device=device)
                with torch.no_grad():
                    wpred = wrong_net(t['coords'], rec_pool.P_W, rec_pool.P_b)
                mw = EVALUATORS[t['modality']](t['target'], wpred, t['meta'])
                results[f"{t['role']}_wrongkey"] = mw
                log(f"  [wrong-key {t['role']}] " + ", ".join(
                    f"{k}={v:.4f}" for k, v in mw.items()))

    results['_meta'] = {
        'epochs_run'   : epochs_run,
        'wall_time_sec': wall,
        'final_loss'   : final_total,
        'cover_hidden' : tasks[0]['cfg']['hidden'],
        'pool_w'       : rcfg.pool_w,
        'pool_b'       : rcfg.pool_b,
        'pool_mode'    : rcfg.pool_mode,
    }
    with open(os.path.join(out_dir, 'metrics.json'), 'w') as f:
        json.dump(results, f, indent=2)
    with open(os.path.join(out_dir, 'config.json'), 'w') as f:
        json.dump(asdict(rcfg), f, indent=2, default=str)
    log_f.close()
    return results


# =============================================================================
# 8. Variant registry (A1 - A13)
# =============================================================================
def build_variants() -> "OrderedDict[str, List[RunConfig]]":
    from collections import OrderedDict
    reg: "OrderedDict[str, List[RunConfig]]" = OrderedDict()

    def V(group, variant, **kw) -> RunConfig:
        return RunConfig(ablation_group=group, variant=variant, **kw)

    # A1 Pool sharing
    reg['A01_pool_sharing'] = [
        V('A01_pool_sharing', 'A1a_isolated', pool_mode='isolated'),
        V('A01_pool_sharing', 'A1b_unified',  pool_mode='unified'),
        V('A01_pool_sharing', 'A1c_wb_split', pool_mode='shared_wb'),   # Ours
    ]
    # A2 KDF sign
    reg['A02_sign_mask'] = [
        V('A02_sign_mask', 'A2a_with_sign'),                            # Ours
        V('A02_sign_mask', 'A2b_no_sign', kdf_no_sign=True),
    ]
    # A3 KDF permutation
    reg['A03_permutation'] = [
        V('A03_permutation', 'A3a_pi_K'),                               # Ours
        V('A03_permutation', 'A3b_sequential', kdf_no_perm=True),
    ]
    # A4 Fourier on/off
    reg['A04_fourier'] = [
        V('A04_fourier', 'A4a_on'),                                     # Ours
        V('A04_fourier', 'A4b_off',
          force_use_fourier={'image': False, 'audio': False, 'video': False}),
    ]
    # A5 Fourier scale
    reg['A05_fourier_scale'] = [
        V('A05_fourier_scale', 'A5a_low',
          force_fourier_scale={'image': 5.0,  'audio': 50.0,  'video': 5.0}),
        V('A05_fourier_scale', 'A5b_mid',
          force_fourier_scale={'image': 10.0, 'audio': 300.0, 'video': 10.0}),  # Ours
        V('A05_fourier_scale', 'A5c_high',
          force_fourier_scale={'image': 20.0, 'audio': 500.0, 'video': 20.0}),
    ]
    # A6 Fourier mapping size
    reg['A06_fourier_mapping'] = [
        V('A06_fourier_mapping', 'A6a_128',
          force_fourier_mapping={'image': 128, 'audio': 128, 'video': 128}),
        V('A06_fourier_mapping', 'A6b_256',
          force_fourier_mapping={'image': 256, 'audio': 256, 'video': 256}),
        V('A06_fourier_mapping', 'A6c_512',
          force_fourier_mapping={'image': 512, 'audio': 512, 'video': 256}),   # Ours
        V('A06_fourier_mapping', 'A6d_1024',
          force_fourier_mapping={'image': 1024, 'audio': 1024, 'video': 512}),
    ]
    # A7 Activation
    reg['A07_activation'] = [
        V('A07_activation', 'A7a_relu',  leaky_slope=0.0),
        V('A07_activation', 'A7b_leaky', leaky_slope=0.01),              # Ours
        V('A07_activation', 'A7c_siren',
          force_is_siren={'image': True, 'audio': True, 'video': True}),
    ]
    # A8 Cover weight
    reg['A08_cover_weight'] = [
        V('A08_cover_weight', 'A8a_w1',
          task_weights={'cover': 1.0, 'image': 1.0, 'audio': 1.0, 'video': 1.0}),  # Ours
        V('A08_cover_weight', 'A8b_w2',
          task_weights={'cover': 2.0, 'image': 1.0, 'audio': 1.0, 'video': 1.0}),
        V('A08_cover_weight', 'A8c_w4',
          task_weights={'cover': 4.0, 'image': 1.0, 'audio': 1.0, 'video': 1.0}),
    ]
    # A9 STFT loss
    reg['A09_stft_loss'] = [
        V('A09_stft_loss', 'A9a_off', stft_loss_weight=0.0),             # Ours
        V('A09_stft_loss', 'A9b_on',  stft_loss_weight=0.1),
    ]
    # A10 grad clip
    reg['A10_grad_clip'] = [
        V('A10_grad_clip', 'A10a_off', grad_clip=0.0),
        V('A10_grad_clip', 'A10b_on',  grad_clip=1.0),                   # Ours
    ]
    # A11 auto-expand
    reg['A11_auto_expand'] = [
        V('A11_auto_expand', 'A11a_off', auto_expand=False),
        V('A11_auto_expand', 'A11b_on',  auto_expand=True),              # Ours
    ]
    # A12 optimizer
    reg['A12_optimizer'] = [
        V('A12_optimizer', 'A12a_adam',  optimizer='adam'),              # Ours
        V('A12_optimizer', 'A12b_adamw', optimizer='adamw'),
        V('A12_optimizer', 'A12c_radam', optimizer='radam'),
    ]
    # A13 scheduler
    reg['A13_scheduler'] = [
        V('A13_scheduler', 'A13a_cosine',   scheduler='cosine'),         # Ours
        V('A13_scheduler', 'A13b_constant', scheduler='constant'),
        V('A13_scheduler', 'A13c_step',     scheduler='step'),
    ]
    # A14 learning rate
    reg['A14_lr'] = [
        V('A14_lr', 'A14a_1e-3', lr=1e-3),
        V('A14_lr', 'A14b_3e-3', lr=3e-3),                              # Ours
        V('A14_lr', 'A14c_1e-2', lr=1e-2),
    ]
    return reg


# =============================================================================
# 9. Reporting: CSV, LaTeX, figures
# =============================================================================
METRIC_KEYS = {
    'image': ['PSNR(dB)', 'SSIM'],
    'video': ['PSNR(dB)', 'SSIM'],
    'audio': ['SNR(dB)',  'MAE'  ],
}

ROLE_MODALITY = {
    'cover'  : 'image',
    'secret0': 'audio',
    'secret1': 'image',
    'secret2': 'video',
}


def collect_rows(all_results: Dict[str, Dict[str, Any]]) -> List[Dict[str, Any]]:
    rows = []
    for key, res in all_results.items():
        group, variant = key.split('__', 1)
        row = {'group': group, 'variant': variant}
        for role, mod in ROLE_MODALITY.items():
            for mk in METRIC_KEYS[mod]:
                col = f"{role}/{mk}"
                row[col] = res.get(role, {}).get(mk, float('nan'))
            # wrong-key (secret only)
            if role.startswith('secret'):
                wk = f"{role}_wrongkey"
                for mk in METRIC_KEYS[mod]:
                    row[f"{wk}/{mk}"] = res.get(wk, {}).get(mk, float('nan'))
        meta = res.get('_meta', {})
        row['epochs_run']    = meta.get('epochs_run', -1)
        row['wall_time_sec'] = meta.get('wall_time_sec', -1.0)
        row['final_loss']    = meta.get('final_loss', float('nan'))
        rows.append(row)
    return rows


def write_master_csv(rows: List[Dict[str, Any]], path: str):
    os.makedirs(os.path.dirname(path), exist_ok=True)
    cols = ['group', 'variant']
    for role, mod in ROLE_MODALITY.items():
        for mk in METRIC_KEYS[mod]:
            cols.append(f"{role}/{mk}")
        if role.startswith('secret'):
            for mk in METRIC_KEYS[mod]:
                cols.append(f"{role}_wrongkey/{mk}")
    cols += ['epochs_run', 'wall_time_sec', 'final_loss']
    with open(path, 'w', newline='') as f:
        w = csv.DictWriter(f, fieldnames=cols)
        w.writeheader()
        for r in rows:
            w.writerow({c: r.get(c, '') for c in cols})
    print(f"[Report] master CSV -> {path}")


def write_group_latex(group: str, rows: List[Dict[str, Any]], path: str):
    role_display = [('cover', 'Cover (Image)'),
                    ('secret0', 'Secret0 (Audio)'),
                    ('secret1', 'Secret1 (Image)'),
                    ('secret2', 'Secret2 (Video)')]
    header_cells = ['Variant']
    for role, disp in role_display:
        mod = ROLE_MODALITY[role]
        for mk in METRIC_KEYS[mod]:
            header_cells.append(f"{disp} {mk}")
    lines = [
        "\\begin{table}[!t]",
        "\\centering",
        "\\small",
        f"\\caption{{Ablation study for group {group}.}}",
        f"\\label{{tab:{group}}}",
        "\\begin{tabular}{l" + "c" * (len(header_cells) - 1) + "}",
        "\\toprule",
        " & ".join(header_cells) + " \\\\",
        "\\midrule",
    ]
    for r in rows:
        cells = [r['variant'].replace('_', '\\_')]
        for role, _ in role_display:
            mod = ROLE_MODALITY[role]
            for mk in METRIC_KEYS[mod]:
                v = r.get(f"{role}/{mk}", float('nan'))
                cells.append(f"{v:.3f}" if isinstance(v, float) else str(v))
        lines.append(" & ".join(cells) + " \\\\")
    lines += ["\\bottomrule", "\\end{tabular}", "\\end{table}"]
    os.makedirs(os.path.dirname(path), exist_ok=True)
    with open(path, 'w') as f:
        f.write("\n".join(lines))
    print(f"[Report] LaTeX -> {path}")


def plot_group_bars(group: str, rows: List[Dict[str, Any]], out_path: str):
    role_display = [('cover',   'Cover (Image)', 'PSNR(dB)'),
                    ('secret0', 'Secret0 (Audio)', 'SNR(dB)'),
                    ('secret1', 'Secret1 (Image)', 'PSNR(dB)'),
                    ('secret2', 'Secret2 (Video)', 'PSNR(dB)')]
    variants = [r['variant'] for r in rows]
    x = np.arange(len(variants))
    width = 0.2
    fig, ax = plt.subplots(figsize=(max(7, 1.6 * len(variants)), 4.2))
    colors = ['#4C72B0', '#DD8452', '#55A467', '#C44E52']
    for i, (role, disp, mk) in enumerate(role_display):
        vals = [r.get(f"{role}/{mk}", float('nan')) for r in rows]
        ax.bar(x + (i - 1.5) * width, vals, width,
               label=f"{disp} [{mk}]", color=colors[i], edgecolor='black', linewidth=0.4)
    ax.set_xticks(x)
    ax.set_xticklabels(variants, rotation=20, ha='right')
    ax.set_ylabel('Quality (higher is better)')
    ax.set_title(f'Ablation: {group}')
    ax.legend(loc='best', framealpha=0.9)
    plt.tight_layout()
    plt.savefig(out_path)
    plt.close()
    print(f"[Report] figure -> {out_path}")


def render_reports(all_results: Dict[str, Dict[str, Any]],
                   variant_registry: Dict[str, List[RunConfig]]):
    os.makedirs(TABLE_DIR, exist_ok=True)
    os.makedirs(FIG_DIR,   exist_ok=True)

    rows = collect_rows(all_results)
    write_master_csv(rows, os.path.join(TABLE_DIR, 'ablation_full.csv'))

    for group, variants in variant_registry.items():
        group_rows = [r for r in rows if r['group'] == group]
        if not group_rows:
            continue
        write_group_latex(group, group_rows,
                          os.path.join(TABLE_DIR, f'{group}.tex'))
        plot_group_bars(group, group_rows,
                        os.path.join(FIG_DIR, f'{group}.png'))

    # summary grid (PSNR/SNR of cover + secret0 across all variants)
    fig, axes = plt.subplots(4, 4, figsize=(20, 14))
    axes = axes.flatten()
    for i, (group, variants) in enumerate(variant_registry.items()):
        if i >= len(axes): break
        gr = [r for r in rows if r['group'] == group]
        ax = axes[i]
        if not gr:
            ax.set_visible(False); continue
        vs = [r['variant'] for r in gr]
        cov = [r.get('cover/PSNR(dB)', float('nan')) for r in gr]
        s0  = [r.get('secret0/SNR(dB)', float('nan')) for r in gr]
        s1  = [r.get('secret1/PSNR(dB)', float('nan')) for r in gr]
        s2  = [r.get('secret2/PSNR(dB)', float('nan')) for r in gr]
        x = np.arange(len(vs)); w = 0.2
        ax.bar(x - 1.5 * w, cov, w, label='Cover PSNR')
        ax.bar(x - 0.5 * w, s0,  w, label='Sec0 SNR')
        ax.bar(x + 0.5 * w, s1,  w, label='Sec1 PSNR')
        ax.bar(x + 1.5 * w, s2,  w, label='Sec2 PSNR')
        ax.set_xticks(x); ax.set_xticklabels(vs, rotation=25, ha='right', fontsize=7)
        ax.set_title(group, fontsize=10)
        ax.legend(fontsize=7)
    for j in range(len(variant_registry), len(axes)):
        axes[j].set_visible(False)
    plt.tight_layout()
    grid_path = os.path.join(FIG_DIR, 'summary_grid.png')
    plt.savefig(grid_path); plt.close()
    print(f"[Report] summary grid -> {grid_path}")


# =============================================================================
# 10. Main
# =============================================================================
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--epochs', type=int, default=DEFAULT_EPOCHS)
    parser.add_argument('--only', nargs='*', default=None,
                        help='Only run these groups (e.g. A02_sign_mask)')
    parser.add_argument('--only-variant', nargs='*', default=None)
    parser.add_argument('--reports-only', action='store_true',
                        help='Skip training; read metrics.json from disk and re-render tables/figures.')
    parser.add_argument('--seed', type=int, default=DEFAULT_SEED)
    args = parser.parse_args()

    os.makedirs(RESULTS_ROOT, exist_ok=True)
    os.makedirs(FIG_DIR,      exist_ok=True)
    os.makedirs(TABLE_DIR,    exist_ok=True)

    registry = build_variants()
    all_results: Dict[str, Dict[str, Any]] = {}

    if args.reports_only:
        # Load previously saved metrics.json for every variant
        for group, variants in registry.items():
            for v in variants:
                key = v.key()
                mpath = os.path.join(RESULTS_ROOT, group, v.variant, 'metrics.json')
                if os.path.exists(mpath):
                    with open(mpath) as f:
                        all_results[key] = json.load(f)
        render_reports(all_results, registry)
        return

    for group, variants in registry.items():
        if args.only and group not in args.only:
            continue
        for v in variants:
            if args.only_variant and v.variant not in args.only_variant:
                continue
            v.epochs = args.epochs
            v.seed   = args.seed
            out_dir  = os.path.join(RESULTS_ROOT, group, v.variant)
            try:
                res = run_experiment(v, out_dir)
                all_results[v.key()] = res
            except Exception as e:
                print(f"[ERROR] {v.key()}: {e}")
                traceback.print_exc()
            finally:
                torch.cuda.empty_cache()

    render_reports(all_results, registry)
    print("\n========== Ablation Study Finished ==========")
    print(f" Tables : {TABLE_DIR}/")
    print(f" Figures: {FIG_DIR}/")
    print(f" Details: {RESULTS_ROOT}/<group>/<variant>/")


if __name__ == '__main__':
    main()