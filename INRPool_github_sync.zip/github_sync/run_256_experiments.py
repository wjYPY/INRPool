#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
256x256 分辨率下的两组消融实验(顺序执行)
实验1: 固定参数池, 递增秘密数量 (1→42, 停止条件: 所有PSNR<25dB 或 max 42)
实验2: 固定1张秘密, 变化参数池比例 (0.05→1.0, 20组)

运行前自动修改 configs.py 的 resolution 为 (256,256)
运行后自动恢复为 (128,128)
"""

import os, sys, json, shutil, time, re, glob, subprocess

# ==================== 配置 ====================
COVER_PATH = "/root/autodl-tmp/data/Image/Div2k/0801.jpeg"
SECRET_DIR = "/root/autodl-tmp/data/Image/Div2k"
CONFIGS_PATH = "/root/autodl-tmp/configs.py"

EPOCHS = 20000
BATCH_SIZE = 65536          # 256*256=65536, 全批量
INIT_SCHEME = 'kaiming_normal'
PSNR_THRESHOLD = 25.0
MAX_SECRETS = 42

BASE_W = 525056
BASE_B = 1283
RATIOS = [round(0.05 * i, 2) for i in range(1, 21)]

# 输出目录 (加 _256 后缀, 不影响 128x128 结果)
OUT_CAPACITY = "/root/autodl-tmp/outputs_capacity_256"
OUT_POOL     = "/root/autodl-tmp/outputs_pool_capacity_256"

# ==================== 工具函数 ====================
def modify_resolution(new_res):
    """修改 configs.py 中的 IMAGE_CFG resolution"""
    with open(CONFIGS_PATH, 'r', encoding='utf-8') as f:
        content = f.read()
    # 只改 IMAGE_CFG 中的 resolution, 不改 VIDEO_CFG
    # IMAGE_CFG 块在 'IMAGE_CFG = {' 之后
    new_content = re.sub(
        r"(IMAGE_CFG\s*=\s*\{[^}]*?'resolution':\s*\()(\d+),\s*(\d+)(\))",
        lambda m: f"{m.group(1)}{new_res[0]}, {new_res[1]}{m.group(4)}",
        content, count=1, flags=re.DOTALL
    )
    with open(CONFIGS_PATH, 'w', encoding='utf-8') as f:
        f.write(new_content)
    print(f"[CONFIG] IMAGE_CFG resolution -> {new_res}")

def restore_resolution():
    """恢复 resolution 为 (128, 128)"""
    modify_resolution((128, 128))

# ==================== 导入 pipeline (在修改 configs 之后) ====================
def run_experiments():
    # 现在导入 pipeline (会读取修改后的 configs.py)
    from pipeline import run
    from configs import POOL_W_CAPACITY, POOL_B_CAPACITY

    total_start = time.time()

    # ================================================================
    # 实验1: 固定参数池, 递增秘密数量
    # ================================================================
    print("\n" + "=" * 70)
    print("实验1: 固定参数池 (256x256) — 递增秘密数量")
    print("=" * 70)

    all_images = sorted(
        glob.glob(os.path.join(SECRET_DIR, "*.jpeg")) +
        glob.glob(os.path.join(SECRET_DIR, "*.jpg")) +
        glob.glob(os.path.join(SECRET_DIR, "*.png"))
    )
    cover_basename = os.path.basename(COVER_PATH)
    secret_images = [img for img in all_images if os.path.basename(img) != cover_basename]

    cap_covers = os.path.join(OUT_CAPACITY, "published_covers")
    cap_results = os.path.join(OUT_CAPACITY, "results")
    os.makedirs(cap_covers, exist_ok=True)
    os.makedirs(cap_results, exist_ok=True)

    cap_table = []
    for n_secrets in range(1, min(len(secret_images), MAX_SECRETS) + 1):
        current_secrets = secret_images[:n_secrets]
        print(f"\n{'='*70}")
        print(f"[256] 实验1-{n_secrets}: {n_secrets} 张秘密图")
        print(f"{'='*70}")
        sys.stdout.flush()

        run_out = os.path.join(OUT_CAPACITY, f"run_{n_secrets}")
        t0 = time.time()
        try:
            metrics = run(
                cover_path=COVER_PATH, secret_paths=current_secrets,
                epochs=EPOCHS, batch_size=BATCH_SIZE,
                out_dir=run_out, init_scheme=INIT_SCHEME, early_stop_loss=None,
            )
            elapsed = time.time() - t0

            cover_m = metrics.get('cover', {})
            cover_psnr = float(cover_m.get('PSNR(dB)', 0))

            secret_psnrs, secret_ssims, secret_maes, secret_rmses = [], [], [], []
            for k in sorted(metrics.keys()):
                if k.startswith('secret'):
                    m = metrics[k]
                    secret_psnrs.append(float(m.get('PSNR(dB)', 0)))
                    secret_ssims.append(float(m.get('SSIM', 0)))
                    secret_maes.append(float(m.get('MAE', 0)))
                    secret_rmses.append(float(m.get('RMSE', 0)))

            n = len(secret_psnrs)
            avg_psnr = sum(secret_psnrs)/n if n else 0
            min_psnr_s = min(secret_psnrs) if secret_psnrs else 0
            max_psnr_s = max(secret_psnrs) if secret_psnrs else 0

            # 保存封面图
            recovered = os.path.join(run_out, "recovered_cover_image.jpg")
            if os.path.exists(recovered):
                shutil.copy(recovered, os.path.join(cap_covers, f"cover_with_{n_secrets}secrets.jpg"))

            result = {
                'n_secrets': n_secrets,
                'cover_PSNR': round(cover_psnr, 4),
                'cover_SSIM': round(float(cover_m.get('SSIM', 0)), 4),
                'cover_MAE': round(float(cover_m.get('MAE', 0)), 4),
                'cover_RMSE': round(float(cover_m.get('RMSE', 0)), 4),
                'avg_secret_PSNR': round(avg_psnr, 4),
                'avg_secret_SSIM': round(sum(secret_ssims)/n if n else 0, 4),
                'avg_secret_MAE': round(sum(secret_maes)/n if n else 0, 4),
                'avg_secret_RMSE': round(sum(secret_rmses)/n if n else 0, 4),
                'min_secret_PSNR': round(min_psnr_s, 4),
                'max_secret_PSNR': round(max_psnr_s, 4),
                'elapsed_sec': round(elapsed, 1),
            }
            cap_table.append(result)
            with open(os.path.join(cap_results, 'capacity_results_256.json'), 'w', encoding='utf-8') as f:
                json.dump(cap_table, f, indent=2, ensure_ascii=False)

            all_psnrs = [cover_psnr] + secret_psnrs
            print(f"\n  封面: PSNR={cover_psnr:.2f}  SSIM={float(cover_m.get('SSIM',0)):.4f}")
            print(f"  秘密(均值): PSNR={avg_psnr:.2f}  范围[{min_psnr_s:.2f}~{max_psnr_s:.2f}]")
            print(f"  耗时: {elapsed:.0f}s ({elapsed/60:.1f}min)")
            below = sum(1 for p in all_psnrs if p < PSNR_THRESHOLD)
            print(f"  低于25dB: {below}/{len(all_psnrs)}")
            sys.stdout.flush()

            if max(all_psnrs) < PSNR_THRESHOLD:
                print(f"\n  *** 所有图像 PSNR < {PSNR_THRESHOLD}dB, 停止实验1 ***")
                break

        except Exception as e:
            import traceback; traceback.print_exc()
            with open(os.path.join(cap_results, 'capacity_results_256.json'), 'w', encoding='utf-8') as f:
                json.dump(cap_table, f, indent=2, ensure_ascii=False)
            break

    print(f"\n实验1完成: {len(cap_table)} 轮")

    # ================================================================
    # 实验2: 固定1张秘密, 变化参数池比例
    # ================================================================
    print("\n" + "=" * 70)
    print("实验2: 固定1张秘密 (256x256) — 变化参数池比例")
    print("=" * 70)
    sys.stdout.flush()

    SECRET_PATH = secret_images[0]  # 0802.jpeg

    pool_covers = os.path.join(OUT_POOL, "cover_images")
    pool_secrets = os.path.join(OUT_POOL, "secret_images")
    pool_results = os.path.join(OUT_POOL, "results")
    os.makedirs(pool_covers, exist_ok=True)
    os.makedirs(pool_secrets, exist_ok=True)
    os.makedirs(pool_results, exist_ok=True)

    pool_table = []
    for idx, ratio in enumerate(RATIOS):
        pool_w = int(BASE_W * ratio)
        pool_b = int(BASE_B * ratio)
        print(f"\n{'='*70}")
        print(f"[256] 实验2-{idx+1}/20: ratio={ratio:.2f}  pool_w={pool_w:,}  pool_b={pool_b}")
        print(f"{'='*70}")
        sys.stdout.flush()

        run_out = os.path.join(OUT_POOL, f"run_ratio_{ratio:.2f}")
        t0 = time.time()
        try:
            metrics = run(
                cover_path=COVER_PATH, secret_paths=[SECRET_PATH],
                epochs=EPOCHS, batch_size=BATCH_SIZE,
                pool_w=pool_w, pool_b=pool_b,
                out_dir=run_out, init_scheme=INIT_SCHEME, early_stop_loss=None,
            )
            elapsed = time.time() - t0

            cover_m = metrics.get('cover', {})
            secret_m = metrics.get('secret0', {})

            # 保存图片
            for src_name, dst_dir, prefix in [
                ("recovered_cover_image.jpg", pool_covers, "cover"),
                ("recovered_secret0_image.jpg", pool_secrets, "secret")]:
                src = os.path.join(run_out, src_name)
                if os.path.exists(src):
                    shutil.copy(src, os.path.join(dst_dir, f"{prefix}_ratio_{ratio:.2f}.jpg"))

            result = {
                'ratio': ratio, 'pool_w': pool_w, 'pool_b': pool_b,
                'cover_PSNR': round(float(cover_m.get('PSNR(dB)', 0)), 4),
                'cover_SSIM': round(float(cover_m.get('SSIM', 0)), 4),
                'cover_MAE': round(float(cover_m.get('MAE', 0)), 4),
                'cover_RMSE': round(float(cover_m.get('RMSE', 0)), 4),
                'secret_PSNR': round(float(secret_m.get('PSNR(dB)', 0)), 4),
                'secret_SSIM': round(float(secret_m.get('SSIM', 0)), 4),
                'secret_MAE': round(float(secret_m.get('MAE', 0)), 4),
                'secret_RMSE': round(float(secret_m.get('RMSE', 0)), 4),
                'elapsed_sec': round(elapsed, 1),
            }
            pool_table.append(result)
            with open(os.path.join(pool_results, 'pool_capacity_results_256.json'), 'w', encoding='utf-8') as f:
                json.dump(pool_table, f, indent=2, ensure_ascii=False)

            print(f"\n  封面: PSNR={result['cover_PSNR']:.2f}  SSIM={result['cover_SSIM']:.4f}")
            print(f"  秘密: PSNR={result['secret_PSNR']:.2f}  SSIM={result['secret_SSIM']:.4f}")
            print(f"  耗时: {elapsed:.0f}s ({elapsed/60:.1f}min)")
            sys.stdout.flush()

        except Exception as e:
            import traceback; traceback.print_exc()
            pool_table.append({'ratio': ratio, 'error': str(e)})
            with open(os.path.join(pool_results, 'pool_capacity_results_256.json'), 'w', encoding='utf-8') as f:
                json.dump(pool_table, f, indent=2, ensure_ascii=False)

    print(f"\n实验2完成: {len(pool_table)} 组")

    # ================================================================
    # 汇总
    # ================================================================
    total = time.time() - total_start
    print(f"\n{'='*70}")
    print(f"全部完成! 总耗时: {total/3600:.1f} 小时")
    print(f"实验1 (递增秘密): {len(cap_table)} 轮 -> {OUT_CAPACITY}")
    print(f"实验2 (变化参数池): {len(pool_table)} 组 -> {OUT_POOL}")
    print(f"{'='*70}")
    sys.stdout.flush()


if __name__ == "__main__":
    try:
        # 修改 resolution 为 256x256
        modify_resolution((256, 256))
        # 运行实验
        run_experiments()
    finally:
        # 无论成功失败, 都恢复 resolution 为 128x128
        restore_resolution()
        print("[CONFIG] resolution 已恢复为 (128, 128)")
