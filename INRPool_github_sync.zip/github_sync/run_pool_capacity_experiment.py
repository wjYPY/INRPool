#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
参数池容量消融实验
- 封面: 0801.jpeg (固定)
- 秘密: 0802.jpeg (固定1张)
- 变量: 参数池大小 / 网络参数量 = 0.05 ~ 1.00 (共20组)
- epochs=10000, batch_size=16384, kaiming_normal
- 每组保存: cover/secret 的4指标 + 提取图片
"""

import os
import sys
import json
import shutil
import time

import matplotlib
matplotlib.use('Agg')

from pipeline import run
from configs import POOL_W_CAPACITY, POOL_B_CAPACITY

# ==================== 实验配置 ====================
COVER_PATH = "/root/autodl-tmp/data/Image/Div2k/0801.jpeg"
SECRET_PATH = "/root/autodl-tmp/data/Image/Div2k/0802.jpeg"

EPOCHS = 10000
BATCH_SIZE = 16384
INIT_SCHEME = 'kaiming_normal'

# 基准网络参数量 (= 载体网络大小)
BASE_W = POOL_W_CAPACITY   # 525056
BASE_B = POOL_B_CAPACITY   # 1283

# 参数池比例: 0.05 ~ 1.00, 共20组
RATIOS = [round(0.05 * i, 2) for i in range(1, 21)]

# ==================== 输出目录 ====================
BASE_OUTPUT = "/root/autodl-tmp/outputs_pool_capacity"
COVER_DIR   = os.path.join(BASE_OUTPUT, "cover_images")
SECRET_DIR  = os.path.join(BASE_OUTPUT, "secret_images")
RESULTS_DIR = os.path.join(BASE_OUTPUT, "results")
os.makedirs(COVER_DIR, exist_ok=True)
os.makedirs(SECRET_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

# ==================== 实验主循环 ====================
print("=" * 70)
print("参数池容量消融实验")
print("=" * 70)
print(f"封面: {COVER_PATH}")
print(f"秘密: {SECRET_PATH}")
print(f"基准网络: W={BASE_W:,}, b={BASE_B:,}")
print(f"比例: {RATIOS}")
print(f"每组: epochs={EPOCHS}, batch={BATCH_SIZE}, init={INIT_SCHEME}")
print(f"输出: {BASE_OUTPUT}")
print("=" * 70)
sys.stdout.flush()

results = []
total_start = time.time()

for idx, ratio in enumerate(RATIOS):
    pool_w = int(BASE_W * ratio)
    pool_b = int(BASE_B * ratio)

    print(f"\n{'=' * 70}")
    print(f"实验 {idx+1}/20: 比例={ratio:.2f}  pool_w={pool_w:,}  pool_b={pool_b}")
    print(f"{'=' * 70}")
    sys.stdout.flush()

    run_out = os.path.join(BASE_OUTPUT, f"run_ratio_{ratio:.2f}")
    run_start = time.time()

    try:
        metrics = run(
            cover_path=COVER_PATH,
            secret_paths=[SECRET_PATH],
            epochs=EPOCHS,
            batch_size=BATCH_SIZE,
            pool_w=pool_w,
            pool_b=pool_b,
            out_dir=run_out,
            init_scheme=INIT_SCHEME,
            early_stop_loss=None,
        )

        elapsed = time.time() - run_start

        # ---- 提取指标 ----
        cover_m = metrics.get('cover', {})
        secret_m = metrics.get('secret0', {})

        cover_psnr = float(cover_m.get('PSNR(dB)', 0.0))
        cover_ssim = float(cover_m.get('SSIM', 0.0))
        cover_mae  = float(cover_m.get('MAE', 0.0))
        cover_rmse = float(cover_m.get('RMSE', 0.0))

        secret_psnr = float(secret_m.get('PSNR(dB)', 0.0))
        secret_ssim = float(secret_m.get('SSIM', 0.0))
        secret_mae  = float(secret_m.get('MAE', 0.0))
        secret_rmse = float(secret_m.get('RMSE', 0.0))

        # ---- 保存提取的封面图和秘密图 ----
        recovered_cover = os.path.join(run_out, "recovered_cover_image.jpg")
        recovered_secret = os.path.join(run_out, "recovered_secret0_image.jpg")

        if os.path.exists(recovered_cover):
            dst = os.path.join(COVER_DIR, f"cover_ratio_{ratio:.2f}.jpg")
            shutil.copy(recovered_cover, dst)
            print(f"[SAVE] 封面图 -> {dst}")

        if os.path.exists(recovered_secret):
            dst = os.path.join(SECRET_DIR, f"secret_ratio_{ratio:.2f}.jpg")
            shutil.copy(recovered_secret, dst)
            print(f"[SAVE] 秘密图 -> {dst}")

        # ---- 记录结果 ----
        result = {
            'ratio': ratio,
            'pool_w': pool_w,
            'pool_b': pool_b,
            'cover_PSNR': round(cover_psnr, 4),
            'cover_SSIM': round(cover_ssim, 4),
            'cover_MAE':  round(cover_mae, 4),
            'cover_RMSE': round(cover_rmse, 4),
            'secret_PSNR': round(secret_psnr, 4),
            'secret_SSIM': round(secret_ssim, 4),
            'secret_MAE':  round(secret_mae, 4),
            'secret_RMSE': round(secret_rmse, 4),
            'elapsed_sec': round(elapsed, 1),
        }
        results.append(result)

        # ---- 每次保存中间结果 ----
        with open(os.path.join(RESULTS_DIR, 'pool_capacity_results.json'), 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        print(f"\n--- 实验 {idx+1} 结果 (ratio={ratio:.2f}) ---")
        print(f"  封面:  PSNR={cover_psnr:.2f}  SSIM={cover_ssim:.4f}  MAE={cover_mae:.4f}  RMSE={cover_rmse:.4f}")
        print(f"  秘密:  PSNR={secret_psnr:.2f}  SSIM={secret_ssim:.4f}  MAE={secret_mae:.4f}  RMSE={secret_rmse:.4f}")
        print(f"  耗时: {elapsed:.0f}s ({elapsed/60:.1f} min)")
        sys.stdout.flush()

    except Exception as e:
        import traceback
        elapsed = time.time() - run_start
        print(f"\n[ERROR] 实验 {idx+1} (ratio={ratio:.2f}) 失败: {e}")
        traceback.print_exc()
        results.append({
            'ratio': ratio,
            'pool_w': pool_w,
            'pool_b': pool_b,
            'cover_PSNR': 0, 'cover_SSIM': 0, 'cover_MAE': 0, 'cover_RMSE': 0,
            'secret_PSNR': 0, 'secret_SSIM': 0, 'secret_MAE': 0, 'secret_RMSE': 0,
            'elapsed_sec': round(elapsed, 1),
            'error': str(e),
        })
        with open(os.path.join(RESULTS_DIR, 'pool_capacity_results.json'), 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)
        sys.stdout.flush()

# ==================== 输出汇总表格 ====================
total_elapsed = time.time() - total_start

print(f"\n\n{'=' * 130}")
print("参数池容量消融实验 — 汇总表")
print(f"{'=' * 130}")
header = (f"{'比例':<8} {'pool_w':<12} {'Cover_PSNR':<13} {'Cover_SSIM':<13} {'Cover_MAE':<13} {'Cover_RMSE':<13} "
          f"{'Secret_PSNR':<14} {'Secret_SSIM':<14} {'Secret_MAE':<14} {'Secret_RMSE':<14} {'Time(min)':<10}")
print(header)
print("-" * 130)
for r in results:
    row = (f"{r['ratio']:<8.2f} {r['pool_w']:<12,} {r['cover_PSNR']:<13.2f} {r['cover_SSIM']:<13.4f} {r['cover_MAE']:<13.4f} {r['cover_RMSE']:<13.4f} "
           f"{r['secret_PSNR']:<14.2f} {r['secret_SSIM']:<14.4f} {r['secret_MAE']:<14.4f} {r['secret_RMSE']:<14.4f} {r['elapsed_sec']/60:<10.1f}")
    print(row)
print("=" * 130)
print(f"总耗时: {total_elapsed/60:.1f} 分钟")
print(f"完成实验数: {len(results)}")
print(f"JSON 结果: {os.path.join(RESULTS_DIR, 'pool_capacity_results.json')}")
print(f"封面图文件夹: {COVER_DIR}/")
print(f"秘密图文件夹: {SECRET_DIR}/")
sys.stdout.flush()
