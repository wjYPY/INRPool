import os, torch, torch.optim as optim, torch.nn.functional as F
from pool    import TypedParamPool
from filler  import FillerProtocol
from models  import PoolNetwork
from configs import (detect_modality, MODALITY_CFG, build_arch,
                     fourier_args_from_cfg, count_params,
                     POOL_W_CAPACITY, POOL_B_CAPACITY)
from data_io import load_data, SAVERS
from metrics import EVALUATORS, pretty_print

MODALITY_WEIGHTS = {'cover': 1.0, 'image': 1.0, 'audio': 1.0, 'video': 1.0}


# =====================================================
# 【删除】_stft_loss 从训练循环中彻底移除
#
# 根本原因：STFT 要求输入是连续时间序列。
# 在随机采样 batch 模式下，时间点是乱序的，
# 对乱序时间点做 STFT 得到的频谱毫无物理意义，
# 产生的梯度会与 MSE 梯度剧烈冲突，拉垮 cover 质量。
# 证据：添加 0.1 权重 STFT 后 cover 音频 SNR 从 +9.5 → -0.9 dB。
#
# 评测时仍然使用 STFT 指标（metrics.py 中），那是在完整重建信号上算的，是对的。
# =====================================================


def _get_task_weight(task: dict) -> float:
    if task['role'] == 'cover':
        return MODALITY_WEIGHTS['cover']
    return MODALITY_WEIGHTS.get(task['modality'], 1.0)


def _fix_path(p: str) -> str:
    if p.startswith('.data/'):
        p = './data/' + p[len('.data/'):]
    return p


def run(cover_path: str, secret_paths: list,
        epochs: int = 10000, batch_size: int = 16384, lr: float = 3e-3,
        pool_w: int = POOL_W_CAPACITY, pool_b: int = POOL_B_CAPACITY,
        out_dir: str = './outputs', artifacts_dir: str = './artifacts',
        device: str = None, early_stop_loss: float = 1e-7, grad_clip: float = 1.0,
        init_scheme: str = 'kaiming_normal',
        # [R1-3/R1-8 2026-10-17] 密钥注入: 最小改动, 允许显式传入 key; 不传则保持原默认行为
        secret_keys: list = None):
    device = device or ('cuda' if torch.cuda.is_available() else 'cpu')
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(artifacts_dir, exist_ok=True)
    print(f"========== HA-PoolINR 终极过拟合映射 (device={device}) ==========")

    cover_path   = _fix_path(cover_path)
    secret_paths = [_fix_path(p) for p in secret_paths]

    # ── 任务构建 ──────────────────────────────────────────
    tasks = []
    c_mod = detect_modality(cover_path)
    tasks.append({'role': 'cover', 'key': 'COVER_KEY_V1',
                  'modality': c_mod, 'cfg': MODALITY_CFG[c_mod], 'path': cover_path})
    print(f"[Cover] {cover_path}  →  模态={c_mod}")

    for i, sp in enumerate(secret_paths):
        mod = detect_modality(sp)
        _key = (secret_keys[i] if secret_keys and i < len(secret_keys)
                else f'SECRET_KEY_{i}_V1')   # [密钥注入] 不传 secret_keys 时保持原默认行为
        tasks.append({'role': f'secret{i}', 'key': _key,
                      'modality': mod, 'cfg': MODALITY_CFG[mod], 'path': sp})
        print(f"[Secret{i}] {sp}  →  模态={mod}")

    N_W, N_b = pool_w, pool_b
    print(f"\n[Capacity] 全局池容量 N_W={N_W:,}, N_b={N_b:,}")

    # ── 架构检查 & 可选自动扩容 ───────────────────────────
    for t in tasks:
        t['arch'] = build_arch(t['cfg'])
        nW, nb = count_params(t['arch'])
        rW, rb = nW / N_W, nb / N_b
        role_tag = '🟢Cover' if t['role'] == 'cover' else '🔵Secret'
        print(f"  {role_tag}({t['modality']:<5}): nW={nW:<7,} nb={nb:<5}  "
              f"r_W={rW:.2f}  r_b={rb:.2f}")

    cover_nW, cover_nb = count_params(tasks[0]['arch'])
    if cover_nW < N_W or cover_nb < N_b:
        print(f"\n[Capacity Check] ⚠ Cover 容量不足，正在自动扩容 (步长 hidden+=32)...")
        while True:
            cover_nW, cover_nb = count_params(build_arch(tasks[0]['cfg']))
            if cover_nW >= N_W and cover_nb >= N_b:
                break
            tasks[0]['cfg']['hidden'] += 32
        tasks[0]['arch'] = build_arch(tasks[0]['cfg'])
        cover_nW, cover_nb = count_params(tasks[0]['arch'])
        print(f"   ✅ Cover 扩容完毕! 新架构 hidden={tasks[0]['cfg']['hidden']}")
        print(f"   新参数量: W={cover_nW:,} (r_W={cover_nW/N_W:.2f}), "
              f"b={cover_nb} (r_b={cover_nb/N_b:.2f})")
    else:
        print(f"\n[Capacity Check] ✅ Cover 容量充足，无需自动扩容。")

    # ── 数据加载 ──────────────────────────────────────────
    for t in tasks:
        t['coords'], t['target'], t['meta'] = load_data(
            t['modality'], t['path'], t['cfg'], device)

    # ── 参数池 & 网络 ────────────────────────────────────
    pool = TypedParamPool(n_w=N_W, n_b=N_b, device=device, init_scheme=init_scheme)
    pool.P_W.requires_grad_(True)
    pool.P_b.requires_grad_(True)

    nets = {
        t['role']: PoolNetwork(
            key=t['key'], arch=t['arch'], pool_w_size=N_W, pool_b_size=N_b,
            use_fourier=t['cfg']['use_fourier'],
            fourier_args=fourier_args_from_cfg(t['cfg']),
            is_siren=t['cfg']['is_siren'], device=device, leaky_slope=0.01,
        ).to(device)
        for t in tasks
    }

    # ── 优化器 & 调度 ────────────────────────────────────
    optimizer = optim.AdamW([pool.P_W, pool.P_b], lr=lr, weight_decay=1e-4)
    scheduler = optim.lr_scheduler.CosineAnnealingLR(
        optimizer, T_max=epochs, eta_min=1e-5)
    task_weights = {t['role']: _get_task_weight(t) for t in tasks}

    log_interval = max(1, epochs // 20)

    # ── 训练循环 ─────────────────────────────────────────
    print("\n[Training] 开始联合优化 (Full-Batch Overfitting) ...")
    print(f"  策略: 纯 MSE 损失 | 梯度裁剪 max_norm={grad_clip} | "
          f"早停阈值={early_stop_loss}")

        # BEST_CHECKPOINT: 跟踪总loss最优的池权重
    best_total_loss = float('inf'); best_pool = None
    for ep in range(epochs + 1):
        optimizer.zero_grad()
        losses = {}

        for t in tasks:
            n = t['coords'].shape[0]

            # 采样索引（大数据集用随机子集）
            if batch_size >= n:
                idx = torch.arange(n, device=device)
            else:
                idx = torch.randperm(n, device=device)[:batch_size]

            pred = nets[t['role']](t['coords'][idx], pool.P_W, pool.P_b)

            # =====================================================
            # 【核心修复】纯 MSE 训练，彻底不加 STFT loss
            #
            # STFT loss 在随机 batch 上无效（非连续时间点的 STFT 无物理意义），
            # 且权重 0.1 会严重干扰 MSE 优化，导致 cover 音频 SNR 崩溃。
            # 频谱质量改善的正确路径是：更大的池（减少梯度冲突）→ 更好的 MSE 收敛
            #                            → 波形更精准 → 频谱自然更好。
            # =====================================================
            losses[t['role']] = F.mse_loss(pred, t['target'][idx])

        total = sum(task_weights[r] * losses[r] for r in losses) / max(len(losses), 1)
        # [NormalizeFix] 多任务损失按任务数取均值: 与对比方案(Dual-Key等)协议对齐,
        # 避免梯度范数随任务数增长导致clip_grad_norm长期饱和 (2任务时Adam不变性下与旧版等价)

        # 非有限损失：跳过参数更新（包括 scheduler，避免 epoch 计数错位）
        if not torch.isfinite(total):
            print(f"⚠  Epoch {ep}: non-finite loss ({total.item():.4f}), 跳过本轮更新")
            # 【修复】scheduler 也跳过，不然 lr 计数与 epoch 不同步
            continue

        total.backward()

        # 【新增】梯度裁剪：防止多任务梯度叠加时的爆炸（尤其训练初期）
        torch.nn.utils.clip_grad_norm_([pool.P_W, pool.P_b], max_norm=grad_clip)

        optimizer.step()
        scheduler.step()

        # BEST_CHECKPOINT: 记录最优
        _tl = total.item()
        if _tl < best_total_loss:
            best_total_loss = _tl
            best_pool = (pool.P_W.detach().clone(), pool.P_b.detach().clone())

        if ep % log_interval == 0:
            parts = " | ".join(f"{r}:{losses[r].item():.5f}" for r in losses)
            print(f"Epoch {ep:5d} [lr:{scheduler.get_last_lr()[0]:.1e}] "
                  f"| Total {total.item():.4f} | {parts}")

        # 【新增】早停：loss 已经足够小时提前结束，节省 GPU 时间
        if early_stop_loss is not None and ep > 1000 and total.item() < early_stop_loss:
            print(f"\n[EarlyStopping] Epoch {ep}: Total loss={total.item():.2e} "
                  f"< 阈值 {early_stop_loss:.0e}，提前结束训练 ✅")
            break

    # ── 发布阶段 ─────────────────────────────────────────
    # BEST_CHECKPOINT: 恢复总loss最优的池
    if best_pool is not None:
        pool.P_W.data.copy_(best_pool[0]); pool.P_b.data.copy_(best_pool[1])
        print(f'[BestCheckpoint] 恢复最优池 (total loss={best_total_loss:.3e})')
        filler = FillerProtocol(device=device)
    with torch.no_grad():
        cover_state = filler.fill_model(pool, tasks[0]['key'], tasks[0]['arch'])
    cover_publish = {k: v['data'].detach().cpu() for k, v in cover_state.items()}
    torch.save(cover_publish, os.path.join(artifacts_dir, 'cover_published.pth'))
    torch.save({'P_W': pool.P_W.detach().cpu(), 'P_b': pool.P_b.detach().cpu()},
               os.path.join(artifacts_dir, 'real_pool_GT.pth'))

    print("\n[Publish] 已保存 cover_published.pth 与 real_pool_GT.pth")

    # ── 解码验证 ─────────────────────────────────────────
    cover_tensors = {
        n: {'data': cover_publish[n].to(device),
            'type': tasks[0]['arch'][n]['type'],
            's_tau': tasks[0]['arch'][n]['s_tau']}
        for n in cover_publish
    }
    rec_P_W, rec_P_b, cnt_W, cnt_b = filler.decode_to_pool(
        tensors=cover_tensors, key=tasks[0]['key'], arch=tasks[0]['arch'],
        pool_w_size=N_W, pool_b_size=N_b)

    gt = torch.load(os.path.join(artifacts_dir, 'real_pool_GT.pth'),
                    map_location=device)
    err_W = (rec_P_W - gt['P_W'].to(device)).abs().max().item()
    err_b = (rec_P_b - gt['P_b'].to(device)).abs().max().item()

    print(f"[Decode] 验证覆盖率 -> "
          f"未覆盖 W: {(cnt_W==0).sum().item()}/{N_W}, "
          f"未覆盖 b: {(cnt_b==0).sum().item()}/{N_b}")
    print(f"[Decode] 还原精度 -> "
          f"max|ΔP_W|={err_W:.3e}, max|ΔP_b|={err_b:.3e}")

    # ── 重建 & 评测 ──────────────────────────────────────
    rec_pool = TypedParamPool(n_w=N_W, n_b=N_b, device=device)
    rec_pool.P_W = rec_P_W
    rec_pool.P_b = rec_P_b

    print("\n[Reconstruct + Evaluate]")
    all_metrics = {}
    ext_map = {'image': '.jpg', 'audio': '.wav', 'video': '.mp4'}

    for t in tasks:
        with torch.no_grad():
            pred = nets[t['role']](t['coords'], rec_pool.P_W, rec_pool.P_b)
        out_path = os.path.join(
            out_dir, f"recovered_{t['role']}_{t['modality']}{ext_map[t['modality']]}")
        SAVERS[t['modality']](pred, t['meta'], out_path)
        m = EVALUATORS[t['modality']](t['target'], pred, t['meta'])
        all_metrics[t['role']] = m
        pretty_print(f"{t['role']} ({t['modality']}) vs "
                     f"{os.path.basename(t['path'])}", m)

    # ── Wrong-Key 攻击评测（全部 secret） ────────────────
    for t in tasks[1:]:
        wrong_net = PoolNetwork(
            key='WRONG_KEY_ATTACKER', arch=t['arch'],
            pool_w_size=N_W, pool_b_size=N_b,
            use_fourier=t['cfg']['use_fourier'],
            fourier_args=fourier_args_from_cfg(t['cfg']),
            is_siren=t['cfg']['is_siren'], device=device, leaky_slope=0.01,
        ).to(device)
        with torch.no_grad():
            wrong_pred = wrong_net(t['coords'], rec_pool.P_W, rec_pool.P_b)
        pretty_print(
            f"[Wrong-Key 攻击] {t['role']} ({t['modality']})",
            EVALUATORS[t['modality']](t['target'], wrong_pred, t['meta']))
# ── 自动生成论文对比图 (GT vs Reconstructed) ─────────
    try:
        from visualize_paper import make_all_comparisons
        make_all_comparisons(tasks, out_dir=out_dir, fig_dir='./paper_figures')
    except Exception as e:
        print(f"[Vis] 可视化生成失败 (忽略): {e}")

    # ── 保存模型以支持鲁棒性测试 ────────────────────────
    model_path = os.path.join(artifacts_dir, 'trained_model.pth')
    torch.save({
        'pool': {'P_W': pool.P_W.detach().cpu(), 'P_b': pool.P_b.detach().cpu()},
        'nets': {role: net.state_dict() for role, net in nets.items()},
        'tasks': [{
            'role': t['role'], 'key': t['key'], 'modality': t['modality'],
            'cfg': t['cfg'], 'arch': t['arch'], 'path': t['path']
        } for t in tasks],
        'pool_config': {'N_W': N_W, 'N_b': N_b},
        'metrics': all_metrics
    }, model_path)
    print(f"[Model] 已保存训练模型到 {model_path}")

    print("\n========== 全链路完成 ==========")
    return all_metrics


if __name__ == "__main__":
    # ─── 测试用例，按需切换 ────────────────────────────────
    COVER_PATH   = "./data/000000000139.jpg"
    SECRET_PATHS = ["./data/000000000632.jpg","./data/000000000285.jpg","./data/000000000724.jpg","./data/000000000776.jpg","./data/000000000785.jpg","./data/000000000802.jpg","./data/000000000872.jpg","./data/000000000885.jpg","./data/000000001000.jpg","./data/000000001268.jpg"]

    #COVER_PATH   = "./data/1-137-A-32.wav"
    #SECRET_PATHS = ["./data/bigbuckbunny.mp4",]#"./data/000000000632.jpg","./data/1-1791-A-26.wav"]

    #COVER_PATH   = "./data/3040808-uhd_3840_2160_30fps.mp4"
    #SECRET_PATHS = ["./data/bigbuckbunny.mp4"]

    run(COVER_PATH, SECRET_PATHS, epochs=10000, batch_size=16384)