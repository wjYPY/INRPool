#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
HA-PoolINR 图片数据集实验 - 运行3次, 每个数据集取最优结果
完全不变的数据和配置, 只是跑3次取最好
"""
import os, sys, json, time, torch
os.chdir('/root/autodl-tmp')
sys.path.insert(0, '/root/autodl-tmp')

from pipeline import run as pipeline_run

OUT = '/root/autodl-tmp/user_img_3runs'
os.makedirs(OUT, exist_ok=True)

DATA_ROOT = "./data/Image"
DATASETS = [
    {"tag": "COCO", "cover": f"{DATA_ROOT}/COCO/000000000872.jpg", "secret": f"{DATA_ROOT}/COCO/000000000885.jpg"},
    {"tag": "Div2K", "cover": f"{DATA_ROOT}/Div2k/0810.jpeg", "secret": f"{DATA_ROOT}/Div2k/0815.jpeg"},
    {"tag": "ImageNet", "cover": f"{DATA_ROOT}/ImageNet/ILSVRC2012_val_00000008.JPEG", "secret": f"{DATA_ROOT}/ImageNet/ILSVRC2012_val_00000009.JPEG"},
]

EPOCHS = 20000
BATCH_SIZE = 10 ** 12
LEARNING_RATE = 3e-3

# 屏蔽可视化
import visualize_paper, types
fake = types.ModuleType("visualize_paper")
fake.make_all_comparisons = lambda *a, **k: None
sys.modules["visualize_paper"] = fake

def run_one_dataset(exp, run_idx):
    tag = exp["tag"]; cover = exp["cover"]; secret = exp["secret"]
    print(f"\n{'='*78}", flush=True)
    print(f"===== {tag} Run {run_idx}/3 =====", flush=True)
    print(f"{'='*78}", flush=True)

    out_dir = os.path.join(OUT, f"{tag}_run{run_idx}")
    art_dir = os.path.join(OUT, f"artifacts_{tag}_run{run_idx}")
    os.makedirs(out_dir, exist_ok=True)
    os.makedirs(art_dir, exist_ok=True)

    t0 = time.time()
    metrics = pipeline_run(
        cover_path=cover, secret_paths=[secret],
        epochs=EPOCHS, batch_size=BATCH_SIZE, lr=LEARNING_RATE,
        out_dir=out_dir, artifacts_dir=art_dir)
    dt = (time.time() - t0) / 60
    print(f"[{tag} Run{run_idx}] {dt:.1f} min", flush=True)
    return metrics

def main():
    all_runs = {}  # {dataset: [run1, run2, run3]}
    # 读取已有结果(断点续跑)
    if os.path.exists(f'{OUT}/all_runs.json'):
        with open(f'{OUT}/all_runs.json') as f:
            all_runs = json.load(f)

    print("=== HA-PoolINR 图片数据集 3次实验 ===\n", flush=True)

    for run_idx in range(1, 4):
        for exp in DATASETS:
            tag = exp["tag"]
            key = f"{tag}_run{run_idx}"
            if key in all_runs:
                print(f"\n--- {key} 已完成, 跳过 ---", flush=True)
                continue
            print(f"\n--- {key} ---", flush=True)
            try:
                metrics = run_one_dataset(exp, run_idx)
                all_runs[key] = {k: {kk: round(float(vv),4) for kk,vv in v.items()} if isinstance(v, dict) else v
                                 for k, v in metrics.items()}
            except Exception as e:
                import traceback; traceback.print_exc()
                all_runs[key] = {"error": str(e)[:200]}
            with open(f'{OUT}/all_runs.json', 'w') as f:
                json.dump(all_runs, f, indent=2, ensure_ascii=False)

    # 每个数据集取最优(按cover PSNR + secret PSNR之和最高)
    best_results = {}
    print("\n\n=== 取最优结果 ===", flush=True)
    for exp in DATASETS:
        tag = exp["tag"]
        runs = []
        for run_idx in range(1, 4):
            key = f"{tag}_run{run_idx}"
            if key in all_runs and 'error' not in all_runs[key]:
                runs.append((run_idx, all_runs[key]))
        if not runs:
            best_results[tag] = {"error": "no valid runs"}
            continue
        # 按cover PSNR + secret0 PSNR排序
        def score(r):
            m = r[1]
            c_psnr = m.get('cover', {}).get('PSNR(dB)', 0)
            s_psnr = m.get('secret0', {}).get('PSNR(dB)', 0)
            return c_psnr + s_psnr
        best_run = max(runs, key=score)
        best_results[tag] = best_run[1]
        print(f"  {tag}: 最优=Run{best_run[0]} (cover PSNR={best_run[1].get('cover',{}).get('PSNR(dB)',0):.2f}, "
              f"secret PSNR={best_run[1].get('secret0',{}).get('PSNR(dB)',0):.2f})", flush=True)

    with open(f'{OUT}/best_results.json', 'w') as f:
        json.dump(best_results, f, indent=2, ensure_ascii=False)
    print("\n=== 完成 ===", flush=True)
    print(json.dumps(best_results, indent=2, ensure_ascii=False), flush=True)
    print("USER_3RUNS_DONE")

if __name__ == '__main__':
    main()
