# run_multimodal_single.py
# 跨模态单秘密隐藏 —— 3 (Cover) × 3 (Secret) = 9 组实验，一键运行
# 需求：
#   1) 每组实验的最终指标都记录下来 → JSON + Markdown 表格 + CSV 总表
#   2) 保存恢复的图片以及原始图片：每个样本单独存放，不加任何图注、无坐标轴、无边距
#      （图像 → GT / Reconstructed；音频 → GT / Reconstructed 波形；视频 → 每帧单独保存）
#      风格与 visualize_paper_separate.py 完全一致（直接复用它）
import os
import csv
import json
import time
import torch

from pipeline import run
from visualize_paper_separate import make_separate_comparisons

# ============ 数据路径（相对当前 cwd = /root/autodl-tmp/） ============
DATA_ROOT = "./data"

# --- Covers ---
COVER_AUDIO = f"{DATA_ROOT}/Audio/1-137-A-32.wav"
COVER_IMAGE = f"{DATA_ROOT}/Image/Div2k/0822.jpeg"
COVER_VIDEO = f"{DATA_ROOT}/Video/3040808-uhd_3840_2160_30fps.mp4"

# --- Secrets ---
SECRET_IMAGE = f"{DATA_ROOT}/Image/Div2k/0824.jpeg"
SECRET_AUDIO = f"{DATA_ROOT}/Audio/1-4211-A-12.wav"
SECRET_VIDEO = f"{DATA_ROOT}/Video/bigbuckbunny.mp4"

# ============ 训练超参 ============
EPOCHS        = 20000
FULL_BATCH    = 65536
LEARNING_RATE = 3e-3

# ============ 输出目录 ============
ROOT_OUT  = "./outputs_multimodal_single"
ROOT_FIGS = "./paper_figures_single"
ROOT_ART  = "./artifacts_multimodal_single"
for d in (ROOT_OUT, ROOT_FIGS, ROOT_ART):
    os.makedirs(d, exist_ok=True)

# ============ 9 组两两组合 ============
COVERS = [
    ("Image", COVER_IMAGE),
    ("Audio", COVER_AUDIO),
    ("Video", COVER_VIDEO),
]
SECRETS = [
    ("Image", SECRET_IMAGE),
    ("Audio", SECRET_AUDIO),
    ("Video", SECRET_VIDEO),
]

EXPERIMENTS = []
for cname, cpath in COVERS:
    for sname, spath in SECRETS:
        EXPERIMENTS.append({
            "tag":    f"Cover{cname}_Secret{sname}",
            "cover":  cpath,
            "secret": spath,
        })


# 屏蔽 pipeline.run 内部的拼接图可视化，避免重复出图
def _install_visualization_hook():
    import sys, types
    fake = types.ModuleType("visualize_paper")
    def _noop(*args, **kwargs): return
    fake.make_all_comparisons = _noop
    sys.modules["visualize_paper"] = fake
_install_visualization_hook()


def _preflight(paths):
    return [p for p in paths if not os.path.exists(p)]


def _reconstruct_tasks_for_vis(cover_path, secret_paths):
    from configs import detect_modality, MODALITY_CFG
    from data_io import load_data

    device = 'cuda' if torch.cuda.is_available() else 'cpu'
    tasks = []
    mod = detect_modality(cover_path)
    _, _, meta = load_data(mod, cover_path, MODALITY_CFG[mod], device)
    tasks.append({'role': 'cover', 'modality': mod,
                  'cfg': MODALITY_CFG[mod], 'path': cover_path, 'meta': meta})
    for i, sp in enumerate(secret_paths):
        m = detect_modality(sp)
        _, _, meta_i = load_data(m, sp, MODALITY_CFG[m], device)
        tasks.append({'role': f'secret{i}', 'modality': m,
                      'cfg': MODALITY_CFG[m], 'path': sp, 'meta': meta_i})
    return tasks


def run_one_experiment(exp):
    tag, cover, secret = exp["tag"], exp["cover"], exp["secret"]

    print("\n" + "=" * 78)
    print(f"===== 开始实验组: {tag} =====")
    print(f"  Cover  : {cover}")
    print(f"  Secret : {secret}")
    print("=" * 78)

    missing = _preflight([cover, secret])
    if missing:
        raise FileNotFoundError(f"以下数据文件不存在: {missing}")

    out_dir = os.path.join(ROOT_OUT,  tag)
    fig_dir = os.path.join(ROOT_FIGS, tag)
    art_dir = os.path.join(ROOT_ART,  tag)
    for d in (out_dir, fig_dir, art_dir):
        os.makedirs(d, exist_ok=True)

    t0 = time.time()
    metrics = run(cover_path=cover, secret_paths=[secret],
                  epochs=EPOCHS, batch_size=FULL_BATCH, lr=LEARNING_RATE,
                  out_dir=out_dir, artifacts_dir=art_dir)
    print(f"\n[{tag}] 训练+评测耗时 {(time.time()-t0)/60:.1f} min")

    # 单独存放：GT / Reconstructed（图像、波形、视频逐帧），无图注/无坐标轴/无边距
    tasks_for_vis = _reconstruct_tasks_for_vis(cover, [secret])
    make_separate_comparisons(tasks_for_vis, out_dir=out_dir,
                              fig_dir=fig_dir, tag=tag, n_video_frames=4)
    return metrics


def _fmt(v):
    return f"{v:.4f}" if isinstance(v, float) else str(v)


# ============ 汇总：JSON + Markdown + CSV（宽表） ============
def _collect_metric_keys(all_results):
    """收集所有 (role, metric) 组合，用于构造统一的 CSV 列。"""
    role_metric_pairs = []
    seen = set()
    for tag, per_role in all_results.items():
        if not isinstance(per_role, dict):
            continue
        for role, mdict in per_role.items():
            if not isinstance(mdict, dict):
                continue
            for k in mdict.keys():
                key = (role, k)
                if key not in seen:
                    seen.add(key)
                    role_metric_pairs.append(key)
    # 稳定排序：cover 在前，secret 按序号，metric 按字母
    def _order(rm):
        role, metric = rm
        r_ord = 0 if role == 'cover' else (1 + int(role.replace('secret', '')) if role.startswith('secret') else 99)
        return (r_ord, role, metric)
    role_metric_pairs.sort(key=_order)
    return role_metric_pairs


def summarize_all(all_results):
    # 1) JSON
    json_path = os.path.join(ROOT_FIGS, "metrics_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    print(f"\n📄 指标 JSON 已保存: {json_path}")

    # 2) Markdown 逐组表 + 汇总表
    md_path = os.path.join(ROOT_FIGS, "metrics_summary.md")
    lines = ["# Cross-Modal Single-Secret Recovery Metrics Summary\n"]

    for tag, per_role in all_results.items():
        lines.append(f"\n## Experiment: **{tag}**\n")
        if isinstance(per_role, dict) and "error" in per_role and \
                all(not isinstance(v, dict) for v in per_role.values()):
            lines.append(f"> ⚠ 实验失败: `{per_role.get('error','unknown')}`\n")
            continue
        if not isinstance(per_role, dict):
            lines.append(f"> ⚠ 无有效指标: `{per_role}`\n")
            continue
        for role, mdict in per_role.items():
            if not isinstance(mdict, dict):
                lines.append(f"\n### {role}\n\n`{mdict}`\n")
                continue
            lines.append(f"\n### {role}\n")
            lines.append("| Metric | Value |")
            lines.append("|---|---|")
            for k, v in mdict.items():
                lines.append(f"| {k} | {_fmt(v)} |")

    # ------- 汇总宽表 (Markdown) -------
    role_metric_pairs = _collect_metric_keys(all_results)
    if role_metric_pairs:
        lines.append("\n\n## 📊 All-Experiments Summary Table\n")
        header = ["Experiment"] + [f"{r}:{m}" for (r, m) in role_metric_pairs]
        lines.append("| " + " | ".join(header) + " |")
        lines.append("|" + "|".join(["---"] * len(header)) + "|")
        for tag, per_role in all_results.items():
            row = [tag]
            for (role, metric) in role_metric_pairs:
                v = ""
                if isinstance(per_role, dict) and isinstance(per_role.get(role), dict):
                    v = per_role[role].get(metric, "")
                row.append(_fmt(v) if v != "" else "")
            lines.append("| " + " | ".join(row) + " |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"📄 指标 Markdown 已保存: {md_path}")

    # 3) CSV 宽表
    csv_path = os.path.join(ROOT_FIGS, "metrics_summary.csv")
    with open(csv_path, "w", encoding="utf-8", newline="") as f:
        w = csv.writer(f)
        header = ["Experiment"] + [f"{r}:{m}" for (r, m) in role_metric_pairs]
        w.writerow(header)
        for tag, per_role in all_results.items():
            row = [tag]
            for (role, metric) in role_metric_pairs:
                v = ""
                if isinstance(per_role, dict) and isinstance(per_role.get(role), dict):
                    v = per_role[role].get(metric, "")
                row.append(_fmt(v) if v != "" else "")
            w.writerow(row)
    print(f"📄 指标 CSV 已保存: {csv_path}")


def main():
    all_results = {}
    for i, exp in enumerate(EXPERIMENTS, 1):
        print(f"\n########## [{i}/{len(EXPERIMENTS)}] {exp['tag']} ##########")
        try:
            all_results[exp["tag"]] = run_one_experiment(exp)
        except Exception as e:
            print(f"❌ [{exp['tag']}] 实验失败: {e}")
            import traceback; traceback.print_exc()
            all_results[exp["tag"]] = {"error": str(e)}
        # 中途也保存一次，避免中断丢失
        try:
            summarize_all(all_results)
        except Exception:
            pass

    summarize_all(all_results)
    print(f"\n🎉 全部 {len(EXPERIMENTS)} 组跨模态单秘密实验完成！")


if __name__ == "__main__":
    main()