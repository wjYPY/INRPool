# visualize_paper.py
# 自动生成 图像 / 音频 / 视频 的真实 vs 重建 对比图
# 真实数据会被裁剪 / 重采样到与实验使用的分辨率一致
#
# 用法 1（推荐）：被 pipeline.py 在评测后自动调用
#     from visualize_paper import make_all_comparisons
#     make_all_comparisons(tasks, out_dir, fig_dir='./paper_figures')
#
# 用法 2（独立运行，需手动给 tasks）：
#     python visualize_paper.py
import os
import math
import numpy as np
import torch
import torchaudio
import torchvision.io as tvio
import torch.nn.functional as F
import matplotlib.pyplot as plt

plt.rcParams.update({'font.size': 12, 'axes.titlesize': 14})

EXT_MAP = {'image': '.jpg', 'audio': '.wav', 'video': '.mp4'}


# ============== 工具：把真实数据加载到与实验相同的尺度 ==============
def _load_image_to_resolution(path, resolution):
    """读图 -> resize 到实验分辨率 -> [H,W,3] float [0,1]"""
    img = tvio.read_image(path).float() / 255.0
    if img.shape[0] == 1: img = img.repeat(3, 1, 1)
    if img.shape[0] == 4: img = img[:3]
    img = F.interpolate(img.unsqueeze(0), size=resolution,
                        mode='bilinear', align_corners=False).squeeze(0)
    return img.permute(1, 2, 0).numpy()  # [H,W,3]

def _sample_frames_by_times(frames_thw3_float, src_fps, frame_times,
                            start_pts_of_read):
    """
    frames_thw3_float: read_video 返回的整段视频，float [0,1]，[T_raw,H,W,3]
    src_fps:           视频原生 fps（用于把秒 → 帧索引）
    frame_times:       目标时间戳列表（秒，绝对）
    start_pts_of_read: 我们调用 read_video 时的 start_pts（秒）
    返回按 frame_times 长度的 [T,H,W,3] float [0,1]
    """
    T_raw = frames_thw3_float.shape[0]
    if T_raw == 0:
        raise RuntimeError("空视频，无法按时间戳采样。")
    out = []
    for t in frame_times:
        rel = max(t - start_pts_of_read, 0.0)
        idx = int(round(rel * src_fps))
        idx = min(max(idx, 0), T_raw - 1)
        out.append(frames_thw3_float[idx])
    return torch.stack(out, dim=0)

def _load_video_to_shape(path, num_frames, resolution,
                         frame_times=None, start_pts=0.0, end_pts=2.0):
    """GT 视频：按 frame_times 采样，与实验保持一致。"""
    frames, _, info = tvio.read_video(
        path, start_pts=start_pts, end_pts=end_pts, pts_unit='sec'
    )
    frames = frames.float() / 255.0
    src_fps = info.get('video_fps',
                       frames.shape[0] / max(end_pts - start_pts, 1e-6))

    if frame_times is not None and len(frame_times) == num_frames:
        frames = _sample_frames_by_times(
            frames, src_fps, frame_times, start_pts
        )
    else:
        # 兜底：均匀采样
        T = frames.shape[0]
        if T >= num_frames:
            idx = torch.linspace(0, T - 1, num_frames).long()
            frames = frames[idx]
        else:
            frames = torch.cat(
                [frames, frames[-1:].repeat(num_frames - T, 1, 1, 1)], dim=0
            )

    frames = F.interpolate(frames.permute(0, 3, 1, 2), size=resolution,
                           mode='bilinear', align_corners=False)
    frames = frames.permute(0, 2, 3, 1).clamp(0, 1)
    return (frames.numpy() * 255).astype(np.uint8)


def _load_audio_to_shape(path, duration, sample_rate):
    """读音频 -> 重采样 -> 截长/补零 -> 峰值归一化 -> [N] float in [-1,1]"""
    wav, sr = torchaudio.load(path)
    if wav.shape[0] > 1: wav = wav.mean(dim=0, keepdim=True)
    if sr != sample_rate:
        wav = torchaudio.transforms.Resample(sr, sample_rate)(wav)
    length = int(sample_rate * duration)
    if wav.shape[1] < length:
        wav = F.pad(wav, (0, length - wav.shape[1]))
    wav = wav[0, :length]
    peak = wav.abs().max().clamp(min=1e-8)
    wav = wav / peak
    return wav.numpy()



def _load_recovered_video(path, num_frames, resolution,
                          frame_times=None, save_fps=None):
    """
    重建视频：我们自己保存的 mp4 时长 = num_frames / save_fps。
    按 frame_times 与保存时时间轴对齐取帧（此时 start_pts=0）。
    """
    frames, _, info = tvio.read_video(path, pts_unit='sec')
    frames = frames.float() / 255.0
    T_raw = frames.shape[0]
    read_fps = info.get('video_fps',
                        save_fps if save_fps else T_raw)

    if frame_times is not None and len(frame_times) == num_frames:
        # 我们保存视频时时间从 0 开始，
        # 而 frame_times 是 GT 视频里的绝对秒；两边都单调递增、
        # 间隔一致，因此把 GT 的相对偏移（相对于 start_pts）用作查询。
        rel_times = [t - frame_times[0] for t in frame_times]
        frames = _sample_frames_by_times(
            frames, read_fps, rel_times, start_pts_of_read=0.0
        )
    else:
        # 兜底：均匀采样 + 必要时 pad
        if T_raw >= num_frames:
            idx = torch.linspace(0, T_raw - 1, num_frames).long()
            frames = frames[idx]
        elif T_raw < num_frames:
            pad_n = num_frames - T_raw
            if T_raw == 0:
                raise RuntimeError(f"读入的重建视频为空: {path}")
            frames = torch.cat(
                [frames, frames[-1:].repeat(pad_n, 1, 1, 1)], dim=0
            )

    frames = F.interpolate(frames.permute(0, 3, 1, 2), size=resolution,
                           mode='bilinear', align_corners=False)
    frames = frames.permute(0, 2, 3, 1).clamp(0, 1)
    return (frames.numpy() * 255).astype(np.uint8)


# ============== 绘图：图像 ==============
def plot_image_comparison(items, out_file):
    """
    items: list of dict, 每个 dict 含
        {'label': 'Cover'/'Secret0'/...,
         'gt': np[H,W,3] in [0,1],
         'rec': np[H,W,3] in [0,1]}
    布局: rows=len(items), cols=2 (GT | Recovered)
    """
    if not items:
        return
    rows = len(items)
    fig, axes = plt.subplots(rows, 2, figsize=(8, 4 * rows))
    if rows == 1:
        axes = np.array([axes])

    for i, it in enumerate(items):
        for j, (key, title_suffix) in enumerate([('gt', 'GT'), ('rec', 'Reconstructed')]):
            ax = axes[i, j]
            ax.imshow(np.clip(it[key], 0, 1))
            ax.axis('off')
            ax.set_title(f"{it['label']} ({title_suffix})", fontsize=14)

    plt.tight_layout()
    plt.savefig(out_file, bbox_inches='tight', dpi=300)
    plt.close()
    print(f"  [Vis] 图像对比已保存: {out_file}")


# ============== 绘图：视频 ==============
def plot_video_comparison(items, out_file, n_show=4):
    """
    items: list of dict
        {'label': 'Cover'/'Secret0',
         'gt_frames':  np[T,H,W,3] uint8,
         'rec_frames': np[T,H,W,3] uint8}
    每个 item 贡献 2 行 (GT, Rec)，每行 n_show 列
    """
    if not items:
        return
    rows = 2 * len(items)
    fig, axes = plt.subplots(rows, n_show, figsize=(4 * n_show, 3 * rows))
    if rows == 1:
        axes = np.array([axes])

    for i, it in enumerate(items):
        for k, (key, suffix) in enumerate([('gt_frames', 'GT'), ('rec_frames', 'Reconstructed')]):
            row = 2 * i + k
            frames = it[key]
            T = frames.shape[0]
            sel = np.linspace(0, T - 1, n_show).astype(int)
            for j, s in enumerate(sel):
                ax = axes[row, j] if rows > 1 else axes[j]
                ax.imshow(frames[s])
                ax.axis('off')
                if j == 0:
                    ax.text(0.03, 0.88, f"{it['label']} ({suffix})",
                            transform=ax.transAxes, color='black', fontsize=13,
                            fontweight='bold',
                            bbox=dict(facecolor='white', alpha=0.75, edgecolor='none'))

    plt.tight_layout()
    plt.savefig(out_file, bbox_inches='tight', dpi=300)
    plt.close()
    print(f"  [Vis] 视频对比已保存: {out_file}")


# ============== 绘图：音频 ==============
def plot_audio_comparison(items, out_file):
    """
    items: list of dict
        {'label': 'Cover'/'Secret0',
         'gt_wav': np[N], 'rec_wav': np[N], 'sample_rate': int}
    布局: rows=len(items), cols=2 (GT | Rec)
    """
    if not items:
        return
    rows = len(items)
    fig, axes = plt.subplots(rows, 2, figsize=(14, 3.5 * rows))
    if rows == 1:
        axes = np.array([axes])

    for i, it in enumerate(items):
        n = min(len(it['gt_wav']), len(it['rec_wav']))
        t = np.linspace(0, n / it['sample_rate'], n)
        for j, (key, suffix) in enumerate([('gt_wav', 'GT'), ('rec_wav', 'Reconstructed')]):
            ax = axes[i, j]
            ax.plot(t, it[key][:n], linewidth=0.5)
            ax.set_ylim(-1.1, 1.1)
            ax.set_title(f"{it['label']} ({suffix})", fontsize=14)
            ax.set_xlabel("Time (s)")
            ax.grid(alpha=0.3)

    plt.tight_layout()
    plt.savefig(out_file, bbox_inches='tight', dpi=300)
    plt.close()
    print(f"  [Vis] 音频对比已保存: {out_file}")


# ============== 主入口：被 pipeline 调用 ==============
def make_all_comparisons(tasks, out_dir='./outputs', fig_dir='./paper_figures'):
    """
    tasks: pipeline.run 内构造的 tasks 列表，每项至少含:
        role: 'cover' / 'secret0' / ...
        modality: 'image' / 'audio' / 'video'
        path: 真实数据路径
        cfg:  对应模态的 MODALITY_CFG
        meta: load_data 返回的 meta（含 resolution / num_frames / sample_rate 等）
    out_dir: pipeline 保存重建结果的目录
    fig_dir: 论文图输出目录
    """
    os.makedirs(fig_dir, exist_ok=True)

    img_items, aud_items, vid_items = [], [], []

    for t in tasks:
        role = t['role']
        mod = t['modality']
        cfg = t['cfg']
        meta = t.get('meta', {})
        rec_path = os.path.join(out_dir, f"recovered_{role}_{mod}{EXT_MAP[mod]}")
        if not os.path.exists(rec_path):
            print(f"  [Vis] ⚠ 找不到重建文件: {rec_path}，跳过")
            continue

        label = role.capitalize()

        if mod == 'image':
            res = meta.get('resolution', cfg['resolution'])
            gt = _load_image_to_resolution(t['path'], res)
            rec = _load_image_to_resolution(rec_path, res)
            img_items.append({'label': label, 'gt': gt, 'rec': rec})

        elif mod == 'audio':
            sr = meta.get('sample_rate', cfg['sample_rate'])
            dur = cfg['duration']
            gt = _load_audio_to_shape(t['path'], dur, sr)
            rec = _load_audio_to_shape(rec_path, dur, sr)
            aud_items.append({'label': label, 'gt_wav': gt, 'rec_wav': rec,
                              'sample_rate': sr})

        elif mod == 'video':
            T   = meta.get('num_frames', cfg['num_frames'])
            res = meta.get('resolution', cfg['resolution'])
            ft  = meta.get('frame_times', None)
            s_pts = meta.get('start_pts', 0.0)
            e_pts = meta.get('end_pts',   2.0)
            save_fps = meta.get('save_fps', None)
            gt  = _load_video_to_shape(
                 t['path'], T, res,
                 frame_times=ft, start_pts=s_pts, end_pts=e_pts,
            )
            rec = _load_recovered_video(
                 rec_path, T, res,
                 frame_times=ft, save_fps=save_fps,
            )
            vid_items.append({'label': label, 'gt_frames': gt, 'rec_frames': rec})

    # 三个模态各画一张
    if img_items:
        plot_image_comparison(img_items, os.path.join(fig_dir, 'Image_Comparison.png'))
    if aud_items:
        plot_audio_comparison(aud_items, os.path.join(fig_dir, 'Audio_Comparison.png'))
    if vid_items:
        plot_video_comparison(vid_items, os.path.join(fig_dir, 'Video_Comparison.png'))

    print(f"\n✅ 所有对比图已保存到 {fig_dir}/")


if __name__ == "__main__":
    # 独立运行时的退化模式：仅提示使用方式
    print("请在 pipeline.py 末尾调用 make_all_comparisons(tasks, out_dir, fig_dir),")
    print("或在此脚本内构造 tasks 后再调用。")