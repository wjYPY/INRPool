#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
256x256 实验2: 固定1张秘密, 变化参数池比例 (0.05~1.0, 20组)
独立运行脚本 — 在实验1被终止后手动启动
注意: configs.py 的 resolution 应已为 (256,256)
"""
import os, sys, json, shutil, time, glob

import matplotlib
matplotlib.use('Agg')

from pipeline import run
from configs import POOL_W_CAPACITY, POOL_B_CAPACITY

COVER_PATH = "/root/autodl-tmp/data/Image/Div2k/0801.jpeg"
SECRET_PATH = "/root/autodl-tmp/data/Image/Div2k/0802.jpeg"

EPOCHS = 20000
BATCH_SIZE = 65536
INIT_SCHEME = 'kaiming_normal'

BASE_W = POOL_W_CAPACITY   # 525056
BASE_B = POOL_B_CAPACITY   # 1283
RATIOS = [round(0.05 * i, 2) for i in range(1, 21)]

OUT_POOL = "/root/autodl-tmp/outputs_pool_capacity_256"
COVER_DIR   = os.path.join(OUT_POOL, "cover_images")
SECRET_DIR  = os.path.join(OUT_POOL, "secret_images")
RESULTS_DIR = os.path.join(OUT_POOL, "results")
os.makedirs(COVER_DIR, exist_ok=True)
os.makedirs(SECRET_DIR, exist_ok=True)
os.makedirs(RESULTS_DIR, exist_ok=True)

print("=" * 70)
print("[256x256] 实验2: 固定1张秘密 — 变化参数池比例 (20组)")
print(f"封面: {COVER_PATH}")
print(f"秘密: {SECRET_PATH}")
print(f"基准网络: W={BASE_W:,}, b={BASE_B:,}")
print(f"epochs={EPOCHS}, batch={BATCH_SIZE}, init={INIT_SCHEME}")
print("=" * 70)
sys.stdout.flush()

results = []
total_start = time.time()

for idx, ratio in enumerate(RATIOS):
    pool_w = int(BASE_W * ratio)
    pool_b = int(BASE_B * ratio)
    print(f"\n{'='*70}")
    print(f"[256] 实验2-{idx+1}/20: ratio={ratio:.2f}  pool_w={pool_w:,}  pool_b={pool_b}")
    print(f"{'='*70}")
    sys.stdout.flush()

    run_out = os.path.join(OUT_POOL, f"run_ratio_{ratio:.2f}")
    t0 = time.time()
    try:
        metrics = run(
            cover_path=COVER_PATH, secret_paths=[SECRET_PATH],
            epochs=EPOCHS, batch_size=BATCH_SIZE,
            pool_w=pool_w, pool_b=pool_b,
            out_dir=run_out, init_scheme=INIT_SCHEME, early_stop_loss=None,
        )
        elapsed = time.time() - t0
        cover_m = metrics.get('cover', {})
        secret_m = metrics.get('secret0', {})

        for src_name, dst_dir, prefix in [
            ("recovered_cover_image.jpg", COVER_DIR, "cover"),
            ("recovered_secret0_image.jpg", SECRET_DIR, "secret")]:
            src = os.path.join(run_out, src_name)
            if os.path.exists(src):
                shutil.copy(src, os.path.join(dst_dir, f"{prefix}_ratio_{ratio:.2f}.jpg"))

        result = {
            'ratio': ratio, 'pool_w': pool_w, 'pool_b': pool_b,
            'cover_PSNR': round(float(cover_m.get('PSNR(dB)', 0)), 4),
            'cover_SSIM': round(float(cover_m.get('SSIM', 0)), 4),
            'cover_MAE': round(float(cover_m.get('MAE', 0)), 4),
            'cover_RMSE': round(float(cover_m.get('RMSE', 0)), 4),
            'secret_PSNR': round(float(secret_m.get('PSNR(dB)', 0)), 4),
            'secret_SSIM': round(float(secret_m.get('SSIM', 0)), 4),
            'secret_MAE': round(float(secret_m.get('MAE', 0)), 4),
            'secret_RMSE': round(float(secret_m.get('RMSE', 0)), 4),
            'elapsed_sec': round(elapsed, 1),
        }
        results.append(result)
        with open(os.path.join(RESULTS_DIR, 'pool_capacity_results_256.json'), 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

        print(f"\n  封面: PSNR={result['cover_PSNR']:.2f}  SSIM={result['cover_SSIM']:.4f}")
        print(f"  秘密: PSNR={result['secret_PSNR']:.2f}  SSIM={result['secret_SSIM']:.4f}")
        print(f"  耗时: {elapsed:.0f}s ({elapsed/60:.1f}min)")
        sys.stdout.flush()
    except Exception as e:
        import traceback; traceback.print_exc()
        results.append({'ratio': ratio, 'error': str(e)})
        with open(os.path.join(RESULTS_DIR, 'pool_capacity_results_256.json'), 'w', encoding='utf-8') as f:
            json.dump(results, f, indent=2, ensure_ascii=False)

total = time.time() - total_start
print(f"\n{'='*70}")
print(f"实验2完成! {len(results)} 组, 总耗时: {total/60:.1f} 分钟")
print(f"{'='*70}")
sys.stdout.flush()
