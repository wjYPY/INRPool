# INRPool GitHub 仓库同步说明

## 目的
论文 ESWA-D-26-36876 (Data availability 声明承诺 source code publicly available) 与公开仓库存在两处不一致，需同步：

1. **pipeline.py 损失函数**：论文式(7)为任务平均损失 (1/(n+1))*sum(L)。服务器训练代码 pipeline.py 第 158 行 `total = sum(task_weights[r] * losses[r] for r in losses) / max(len(losses), 1)` 即平均版。若公开仓库仍为求和版，请以本包 pipeline.py 覆盖。
2. **256-bit 安全配置缺失**：论文 Sec. 4.7 / Table 10 使用 HKDF/HMAC-SHA256 + NIST SP 800-108 的 256-bit 派生。本包新增 kdf_std.py（256-bit 派生实现）与 run_256_experiments.py（安全实验入口），公开仓库缺失，请一并加入。

## 文件 → 论文对应关系
| 文件 | 论文位置 |
|---|---|
| pipeline.py | 式(7) 联合训练；全部重建实验 |
| kdf.py | Sec. 3.5 原始 64-bit 派生配置 |
| kdf_std.py | Sec. 4.7 标准 256-bit 派生配置 (HKDF/HMAC-SHA256, SP 800-108) |
| run_256_experiments.py | Table 10 未授权恢复实验 |
| run_image_datasets.py | Table 2 (COCO/Div2K/ImageNet 20对×3种子) |
| run_multimodal.py / run_multimodal_single.py | Table 3/4 跨模态实验 |
| run_capacity_experiment.py / run_pool_capacity_experiment.py | Table 8 / Fig. 8 |
| ablation_study.py / run_ablation_init.py | Table 13 消融 |
| models.py, pool.py, modules.py, configs.py, data_io.py, metrics.py, filler.py | 方法定义 |
| weak_attacker/weak_attacker_results.json | Table 12 弱攻击者结果 |

## 注意
- 代码中不含任何真实密钥材料（高熵密钥仅存于服务器私有目录）
- 同步后请更新仓库 README：训练目标为任务平均损失（与论文式(7)一致）；标注 64-bit 为原始实验配置、256-bit 为标准安全配置
- Fig. 9 可视化与各表数据均可由对应入口脚本 + 固定种子复现

生成日期: 2026-10-23
