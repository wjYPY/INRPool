# visualize_image_residual.py
# 图像模态专用可视化（纯净版：图片无任何文字，只保存像素）
#   - GT / Reconstructed 单独保存
#   - 残差图 |gt - rec| 分别按 1x, 5x, 10x, 20x, 50x 放大, 每张独立保存

import os
import numpy as np
import torch
import torchvision.io as tvio
import torch.nn.functional as F
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib import rcParams

rcParams['font.family']      = 'serif'
rcParams['font.serif']       = ['Times New Roman', 'DejaVu Serif',
                                'Nimbus Roman', 'Liberation Serif']
rcParams['pdf.fonttype']     = 42
rcParams['ps.fonttype']      = 42

AMPLIFY_FACTORS = [1, 5, 10, 20, 50]


def _load_image_to_resolution(path, resolution):
    img = tvio.read_image(path).float() / 255.0
    if img.shape[0] == 1: img = img.repeat(3, 1, 1)
    if img.shape[0] == 4: img = img[:3]
    img = F.interpolate(img.unsqueeze(0), size=resolution,
                        mode='bilinear', align_corners=False).squeeze(0)
    return img.permute(1, 2, 0).clamp(0, 1).numpy()


def _save_pure_image(arr01, out_file):
    """保存纯图像：无标题、无坐标轴、无边距。"""
    arr = np.clip(arr01, 0, 1)
    h, w = arr.shape[:2]
    fig = plt.figure(figsize=(w / 100.0, h / 100.0), dpi=300)
    ax = plt.Axes(fig, [0., 0., 1., 1.])
    ax.set_axis_off()
    fig.add_axes(ax)
    ax.imshow(arr)
    fig.savefig(out_file, dpi=300, bbox_inches=None, pad_inches=0)
    plt.close(fig)
    print(f"  [Vis] Saved: {out_file}")


def _save_residual(gt01, rec01, factor, out_file):
    diff = np.abs(gt01.astype(np.float32) - rec01.astype(np.float32))
    diff_amp = np.clip(diff * factor, 0.0, 1.0)
    _save_pure_image(diff_amp, out_file)


def make_image_visualizations(cover_path, secret_path,
                              rec_cover_path, rec_secret_path,
                              resolution, fig_dir, tag: str):
    os.makedirs(fig_dir, exist_ok=True)

    items = [
        ('Cover',  cover_path,  rec_cover_path),
        ('Secret', secret_path, rec_secret_path),
    ]

    for role_label, gt_path, rec_path in items:
        if not os.path.exists(rec_path):
            print(f"  [Vis] Missing reconstruction: {rec_path}, skip.")
            continue

        gt  = _load_image_to_resolution(gt_path,  resolution)
        rec = _load_image_to_resolution(rec_path, resolution)

        prefix = f"{tag}_{role_label}"

        _save_pure_image(gt,  os.path.join(fig_dir, f"{prefix}_GT.png"))
        _save_pure_image(rec, os.path.join(fig_dir, f"{prefix}_Reconstructed.png"))

        for f in AMPLIFY_FACTORS:
            _save_residual(
                gt, rec, factor=f,
                out_file=os.path.join(fig_dir, f"{prefix}_Residual_x{f}.png"))

    print(f"\n✅ [{tag}] Image + residual figures saved to: {fig_dir}/")