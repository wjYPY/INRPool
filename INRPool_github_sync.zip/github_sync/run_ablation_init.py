import os
import json
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from pipeline import run

def run_init_ablation():
    # 实验数据设定 (与主实验一致: 1 cover + 3 secrets[image/video/audio])
    COVER_PATH = "./data/000000000139.jpg"
    SECRET_PATHS = [
        "./data/000000000632.jpg",
        "./data/bigbuckbunny.mp4",
        "./data/1-1791-A-26.wav"
    ]

    # 只保留两种初始化方案
    schemes = ['kaiming_normal', 'xavier_normal']

    # 实验配置
    EPOCHS = 3000
    BATCH_SIZE = 16384

    results = {}
    base_out_dir = './outputs_ablation'

    print("========== 开始参数池初始化消融实验 ==========")
    for scheme in schemes:
        print(f"\n>>> 正在测试初始化策略: [{scheme}] <<<")
        scheme_out_dir = os.path.join(base_out_dir, scheme)

        try:
            # 调用 pipeline.py 的 run 函数
            metrics = run(
                cover_path=COVER_PATH,
                secret_paths=SECRET_PATHS,
                epochs=EPOCHS,
                batch_size=BATCH_SIZE,
                out_dir=scheme_out_dir,
                init_scheme=scheme,
                early_stop_loss=None  # 消融时跑满 Epoch 观察收敛终态
            )

            # 保存完整指标 (含所有模态的所有指标)
            results[scheme] = metrics

            # 打印摘要
            for role, m in metrics.items():
                parts = [f"{k}={v:.4f}" for k, v in m.items()]
                print(f"  [{role}] {', '.join(parts)}")

        except Exception as e:
            import traceback
            print(f"[{scheme}] 测试失败: {e}")
            traceback.print_exc()
            results[scheme] = {}

    # 保存完整结果为 JSON
    os.makedirs(base_out_dir, exist_ok=True)
    with open(os.path.join(base_out_dir, 'init_ablation_results.json'), 'w') as f:
        json.dump(results, f, indent=4, default=float)

    # ================= 绘制消融对比图 =================
    plot_ablation_results(results, os.path.join(base_out_dir, 'Init_Ablation_Chart.png'))

    # ================= 打印汇总表格 =================
    print_summary_table(results)


def plot_ablation_results(results, out_path):
    schemes = list(results.keys())
    n_schemes = len(schemes)
    if n_schemes == 0:
        print("无可用结果, 跳过绘图")
        return

    # 拥有 PSNR(dB) 的角色: cover, secret0(image), secret1(video)
    psnr_roles = ['cover', 'secret0', 'secret1']
    role_labels = ['Cover\n(Image)', 'Secret0\n(Image)', 'Secret1\n(Video)']

    # 收集 PSNR
    psnr_data = {s: [] for s in schemes}
    for scheme in schemes:
        for role in psnr_roles:
            val = results.get(scheme, {}).get(role, {}).get('PSNR(dB)', 0.0)
            psnr_data[scheme].append(float(val))

    # 收集音频 SNR(dB)
    audio_snr = {}
    for scheme in schemes:
        val = results.get(scheme, {}).get('secret2', {}).get('SNR(dB)', 0.0)
        audio_snr[scheme] = float(val)

    # 颜色方案
    colors = ['#4C72B0', '#C44E52']
    width = 0.30

    # 左图: PSNR 对比 (cover/secret0/secret1)
    # 右图: 音频 SNR 对比 (secret2)
    fig, (ax1, ax2) = plt.subplots(1, 2, figsize=(14, 6),
                                  gridspec_kw={'width_ratios': [3, 1]})

    x = list(range(len(psnr_roles)))
    for i, scheme in enumerate(schemes):
        offset = (i - n_schemes / 2 + 0.5) * width
        bars = ax1.bar([xi + offset for xi in x], psnr_data[scheme], width,
                       label=scheme, color=colors[i % len(colors)], edgecolor='white', linewidth=0.5)
        for bar, val in zip(bars, psnr_data[scheme]):
            ax1.text(bar.get_x() + bar.get_width() / 2, bar.get_height() + 0.3,
                     f'{val:.1f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

    ax1.set_ylabel('PSNR (dB)', fontsize=12)
    ax1.set_title('PSNR Comparison (Image & Video)', fontsize=13, fontweight='bold')
    ax1.set_xticks(x)
    ax1.set_xticklabels(role_labels, fontsize=10)
    ax1.legend(fontsize=10, loc='lower right')
    ax1.grid(axis='y', alpha=0.3, linestyle='--')
    all_psnr = [v for vals in psnr_data.values() for v in vals]
    ax1.set_ylim(0, max(all_psnr) * 1.15 if all_psnr else 60)

    # 右图: 音频 SNR
    x2 = [0]
    for i, scheme in enumerate(schemes):
        offset = (i - n_schemes / 2 + 0.5) * width
        bar = ax2.bar([xi + offset for xi in x2], [audio_snr[scheme]], width,
                      label=scheme, color=colors[i % len(colors)], edgecolor='white', linewidth=0.5)
        for b, val in zip(bar, [audio_snr[scheme]]):
            ax2.text(b.get_x() + b.get_width() / 2, b.get_height() + 0.3,
                     f'{val:.1f}', ha='center', va='bottom', fontsize=9, fontweight='bold')

    ax2.set_ylabel('SNR (dB)', fontsize=12)
    ax2.set_title('Secret2 (Audio)', fontsize=13, fontweight='bold')
    ax2.set_xticks(x2)
    ax2.set_xticklabels(['Audio'], fontsize=10)
    ax2.legend(fontsize=10, loc='lower right')
    ax2.grid(axis='y', alpha=0.3, linestyle='--')
    all_snr = list(audio_snr.values())
    ax2.set_ylim(0, max(all_snr) * 1.2 if all_snr else 40)

    fig.suptitle('Impact of Parameter Pool Initialization on Recovery Quality',
                 fontsize=14, fontweight='bold', y=1.02)
    plt.tight_layout()
    plt.savefig(out_path, dpi=300, bbox_inches='tight')
    plt.close()
    print(f"\n消融实验对比图已保存至: {out_path}")


def print_summary_table(results):
    """打印论文用的汇总表格"""
    print("\n" + "=" * 80)
    print("初始化消融实验汇总表")
    print("=" * 80)

    roles = ['cover', 'secret0', 'secret1', 'secret2']
    role_names = ['Cover (Image)', 'Secret0 (Image)', 'Secret1 (Video)', 'Secret2 (Audio)']

    # 表头
    header = f"{'Scheme':<18}"
    for rn in role_names:
        header += f" | {rn:<28}"
    print(header)
    print("-" * len(header))

    for scheme, metrics in results.items():
        row = f"{scheme:<18}"
        for role in roles:
            m = metrics.get(role, {})
            if 'PSNR(dB)' in m:
                cell = f"PSNR={m['PSNR(dB)']:.2f}, SSIM={m.get('SSIM', 0):.4f}"
            elif 'SNR(dB)' in m:
                cell = f"SNR={m['SNR(dB)']:.2f}, MAE={m.get('MAE', 0):.4f}"
            else:
                cell = "N/A"
            row += f" | {cell:<28}"
        print(row)

    print("=" * len(header))
    print(f"\n完整结果已保存至: ./outputs_ablation/init_ablation_results.json")


if __name__ == "__main__":
    run_init_ablation()
