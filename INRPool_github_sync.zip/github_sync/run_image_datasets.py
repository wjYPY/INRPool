# run_image_datasets.py
# 一键运行图像模态三组数据集单秘密实验:
#   1) COCO     : cover=000000000872.jpg,     secret=000000000885.jpg
#   2) Div2K    : cover=0810.jpeg,            secret=0815.jpeg
#   3) ImageNet : cover=ILSVRC2012_val_00000008.JPEG,
#                 secret=ILSVRC2012_val_00000009.JPEG
#
# - epochs=20000, batch_size=16384
# - 每组: 保存重建图 + GT/Rec 独立可视化 + 残差 5x/10x/20x/50x 独立图
# - 三组指标汇成统一表格 (JSON + Markdown)
#
# 使用: cd /root/autodl-tmp && python run_image_datasets.py

import os
import json
import time
import torch

from pipeline import run
from visualize_image_residual import make_image_visualizations
from configs import IMAGE_CFG

# ============ 数据路径 (cwd = /root/autodl-tmp/) ============
DATA_ROOT = "./data/Image"

DATASETS = [
    {
        "tag":    "COCO",
        "cover":  f"{DATA_ROOT}/COCO/000000000872.jpg",
        "secret": f"{DATA_ROOT}/COCO/000000000885.jpg",
    },
    {
        "tag":    "Div2K",
        "cover":  f"{DATA_ROOT}/Div2k/0810.jpeg",
        "secret": f"{DATA_ROOT}/Div2k/0815.jpeg",
    },
    {
        "tag":    "ImageNet",
        "cover":  f"{DATA_ROOT}/ImageNet/ILSVRC2012_val_00000008.JPEG",
        "secret": f"{DATA_ROOT}/ImageNet/ILSVRC2012_val_00000009.JPEG",
    },
]

# ============ 训练超参 ============
EPOCHS        = 20000
BATCH_SIZE    = 10 ** 12
LEARNING_RATE = 3e-3

# ============ 输出目录 ============
ROOT_OUT  = "./outputs_image_datasets"
ROOT_FIGS = "./paper_figures_image_datasets"
ROOT_ART  = "./artifacts_image_datasets"
for d in (ROOT_OUT, ROOT_FIGS, ROOT_ART):
    os.makedirs(d, exist_ok=True)


# ---------- 屏蔽 pipeline.run 内部原始拼图可视化 ----------
def _install_visualization_hook():
    import sys, types
    fake = types.ModuleType("visualize_paper")
    def _noop(*args, **kwargs): return
    fake.make_all_comparisons = _noop
    sys.modules["visualize_paper"] = fake
_install_visualization_hook()


def _preflight(paths):
    return [p for p in paths if not os.path.exists(p)]


def run_one_dataset(exp):
    tag    = exp["tag"]
    cover  = exp["cover"]
    secret = exp["secret"]

    print("\n" + "=" * 78)
    print(f"===== Dataset: {tag} =====")
    print(f"  Cover : {cover}")
    print(f"  Secret: {secret}")
    print("=" * 78)

    missing = _preflight([cover, secret])
    if missing:
        raise FileNotFoundError(f"以下数据文件不存在: {missing}")

    out_dir = os.path.join(ROOT_OUT,  tag)
    fig_dir = os.path.join(ROOT_FIGS, tag)
    art_dir = os.path.join(ROOT_ART,  tag)
    for d in (out_dir, fig_dir, art_dir):
        os.makedirs(d, exist_ok=True)

    t0 = time.time()
    metrics = run(
        cover_path=cover,
        secret_paths=[secret],
        epochs=EPOCHS,
        batch_size=BATCH_SIZE,
        lr=LEARNING_RATE,
        out_dir=out_dir,
        artifacts_dir=art_dir,
    )
    dt = time.time() - t0
    print(f"\n[{tag}] Training+Evaluation took {dt/60:.1f} min")

    # pipeline.run 里的保存命名规则:
    #   recovered_cover_image.jpg / recovered_secret0_image.jpg
    rec_cover_path  = os.path.join(out_dir, "recovered_cover_image.jpg")
    rec_secret_path = os.path.join(out_dir, "recovered_secret0_image.jpg")

    make_image_visualizations(
        cover_path=cover, secret_path=secret,
        rec_cover_path=rec_cover_path, rec_secret_path=rec_secret_path,
        resolution=IMAGE_CFG['resolution'],
        fig_dir=fig_dir, tag=tag,
    )
    return metrics


# =========================================================
# 汇总 → 统一表格
# =========================================================
IMG_METRIC_ORDER = ['PSNR(dB)', 'SSIM', 'MAE', 'RMSE']


def _fmt(v):
    if isinstance(v, float):
        return f"{v:.4f}"
    return str(v)


def summarize_all(all_results):
    # -------- JSON --------
    json_path = os.path.join(ROOT_FIGS, "metrics_summary.json")
    with open(json_path, "w", encoding="utf-8") as f:
        json.dump(all_results, f, indent=2, ensure_ascii=False)
    print(f"\n📄 Metrics JSON saved: {json_path}")

    # -------- Markdown 统一表 --------
    md_path = os.path.join(ROOT_FIGS, "metrics_summary.md")
    lines = ["# Image Recovery — Cross-Dataset Metrics Summary\n"]

    # 统一大表：一行 = 一个数据集 × 一个角色(Cover/Secret)
    header = "| Dataset | Role | " + " | ".join(IMG_METRIC_ORDER) + " |"
    sep    = "|" + "---|" * (2 + len(IMG_METRIC_ORDER))
    lines.append(header)
    lines.append(sep)

    for tag, per_role in all_results.items():
        if not isinstance(per_role, dict) or "error" in per_role:
            err_msg = per_role.get("error", "unknown") if isinstance(per_role, dict) else str(per_role)
            lines.append(f"| {tag} | — | ⚠ {err_msg} |" + " |" * (len(IMG_METRIC_ORDER) - 1))
            continue
        for role, mdict in per_role.items():
            if not isinstance(mdict, dict):
                continue
            row_vals = [_fmt(mdict.get(m, float('nan'))) for m in IMG_METRIC_ORDER]
            lines.append(f"| {tag} | {role} | " + " | ".join(row_vals) + " |")

    # 每组额外详情
    lines.append("\n---\n\n## Per-Experiment Details\n")
    for tag, per_role in all_results.items():
        lines.append(f"\n### {tag}\n")
        if not isinstance(per_role, dict) or "error" in per_role:
            err_msg = per_role.get("error", "unknown") if isinstance(per_role, dict) else str(per_role)
            lines.append(f"> ⚠ Failed: `{err_msg}`\n")
            continue
        for role, mdict in per_role.items():
            if not isinstance(mdict, dict):
                lines.append(f"\n**{role}**: `{mdict}`\n")
                continue
            lines.append(f"\n**{role}**\n")
            lines.append("| Metric | Value |")
            lines.append("|---|---|")
            for k, v in mdict.items():
                lines.append(f"| {k} | {_fmt(v)} |")

    with open(md_path, "w", encoding="utf-8") as f:
        f.write("\n".join(lines))
    print(f"📄 Metrics Markdown saved: {md_path}")


def main():
    all_results = {}
    for exp in DATASETS:
        try:
            all_results[exp["tag"]] = run_one_dataset(exp)
        except Exception as e:
            print(f"❌ [{exp['tag']}] failed: {e}")
            import traceback; traceback.print_exc()
            all_results[exp["tag"]] = {"error": str(e)}

    summarize_all(all_results)
    print("\n🎉 All three image-dataset experiments finished.")


if __name__ == "__main__":
    main()