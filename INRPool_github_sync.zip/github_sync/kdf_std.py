# kdf_std.py — INRPool 标准 256-bit 密钥派生后端 (接口与 kdf.py 完全兼容)
# 组合: HKDF-Extract (HMAC-SHA256, RFC 5869) + NIST SP 800-108 Counter-Mode KDF (SHA-256)
# 用途覆盖: 权重/偏置池排列 (rejection-sampled Fisher-Yates, 严格无偏),
#           逐张量符号掩码, Fourier 基 (Box-Muller 高斯, 从密码学流确定性生成)
import hashlib, hmac, math
import numpy as np
import torch
from torch import nn

_MODEL_NONCE = ''   # 公开模型 nonce (训练前确定; 空串 = 无域分离)


def set_nonce(nonce_hex):
    global _MODEL_NONCE
    _MODEL_NONCE = nonce_hex or ''


def _ikm(key):
    k = key if isinstance(key, str) else str(key)
    if len(k) == 64 and all(c in '0123456789abcdefABCDEF' for c in k):
        return bytes.fromhex(k)
    return k.encode('utf-8')


def _prk(key, label):
    salt = (_MODEL_NONCE + '||' + label).encode('utf-8')
    return hmac.new(salt, _ikm(key), hashlib.sha256).digest()


def _stream(prk, n):
    out = []; total = 0; i = 1
    while total < n:
        b = hashlib.sha256(prk + i.to_bytes(4, 'big')).digest()
        out.append(b); total += 32; i += 1
    return b''.join(out)[:n]


def _fy_permutation(prk, n):
    if n <= 1:
        return np.arange(n, dtype=np.int64)
    bounds = np.arange(n, 1, -1, dtype=np.int64)
    need = len(bounds)
    raw = np.frombuffer(_stream(prk, need * 8 + 64), dtype=np.uint64)[:need].copy()
    lim = np.array([(((1 << 64) - ((1 << 64) % int(b))) & ((1 << 64) - 1)) for b in bounds], dtype=np.uint64)
    rej = (raw >= lim) & (lim != 0)   # lim==0 表示 2^64 边界(全部接受)
    while rej.any():
        k = int(rej.sum())
        extra = np.frombuffer(_stream(prk, k * 8 + 32), dtype=np.uint64)[:k]
        raw[rej] = extra
        rej = raw >= lim
    j = (raw % bounds.astype(np.uint64)).astype(np.int64)
    p = list(range(n))
    for t in range(need):
        i = n - 1 - t
        jj = int(j[t])
        p[i], p[jj] = p[jj], p[i]
    return np.array(p, dtype=np.int64)


def derive_seed(key, salt=''):
    prk = _prk(key, 'SEED::' + salt)
    return int.from_bytes(_stream(prk, 8), 'big')


class KeyDerivationFunction:
    @staticmethod
    def pool_permutation(key, pool_size, p_type, device='cuda'):
        prk = _prk(key, 'POOL_PERM::' + p_type)
        perm = _fy_permutation(prk, pool_size)
        return torch.tensor(perm, dtype=torch.long, device=device)

    @staticmethod
    def sign_mask(key, tensor_name, num_params, device='cuda'):
        prk = _prk(key, 'SIGN::' + tensor_name)
        bits = np.frombuffer(_stream(prk, (num_params + 7) // 8), dtype=np.uint8)
        b = np.unpackbits(bits)[:num_params].astype(np.int64)
        sm = b * 2 - 1   # int64: {0,1} -> {-1,+1} (uint8 会下溢为 255)
        assert set(np.unique(sm)).issubset({-1, 1})
        return torch.tensor(sm, dtype=torch.long, device=device)


class StdFourierFeature(nn.Module):
    def __init__(self, in_features, mapping_size, scale=10.0, key='', device='cuda'):
        super().__init__()
        prk = _prk(key, 'FOURIER_BASIS')
        n = in_features * mapping_size
        raw = np.frombuffer(_stream(prk, n * 16 + 16), dtype=np.uint64)[:2 * n].astype(np.float64)
        u1 = (raw[:n] + 0.5) / 2.0 ** 64
        u2 = (raw[n:2 * n] + 0.5) / 2.0 ** 64
        r = np.sqrt(-2.0 * np.log(u1))
        theta = 2.0 * np.pi * u2
        B = (r * np.cos(theta)).reshape(in_features, mapping_size) * scale
        self.register_buffer('B', torch.tensor(B, dtype=torch.float32, device=device))

    def forward(self, x):
        xp = (2 * math.pi * x) @ self.B
        return torch.cat([torch.sin(xp), torch.cos(xp)], dim=-1)
